import { GoogleGenerativeAI } from '@google/generative-ai';

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY!);

// Get the Gemini Pro model
function getModel() {
  return genAI.getGenerativeModel({ model: 'gemini-1.5-flash' });
}

export interface ScheduleAnalysis {
  productivityScore: number;
  summary: string;
  insights: string[];
  suggestions: string[];
  timeBreakdown: { category: string; hours: number; percentage: number }[];
  overloadWarnings: string[];
  optimizations: string[];
}

export interface AutoScheduleResult {
  scheduledEvents: {
    title: string;
    start_time: string;
    end_time: string;
    description: string;
    category: string;
  }[];
  explanation: string;
  totalHoursScheduled: number;
}

/**
 * Analyze a user's weekly schedule and provide AI insights
 */
export async function analyzeSchedule(
  events: any[],
  goals: any[],
  habits: any[],
  weekStart: string
): Promise<ScheduleAnalysis> {
  const model = getModel();

  const eventsText = events.map(e => 
    `- ${e.title} (${e.category}, ${new Date(e.start_time).toLocaleString()} - ${new Date(e.end_time).toLocaleString()}, priority: ${e.priority || 'medium'})`
  ).join('\n');

  const goalsText = goals.map(g => 
    `- ${g.title} (${g.type}, target: ${g.target_date || 'ongoing'}, weekly hours: ${g.weekly_hours || 'not set'})`
  ).join('\n');

  const habitsText = habits.map(h => 
    `- ${h.title} (${h.frequency}, ${h.duration_minutes} min, category: ${h.category || 'general'})`
  ).join('\n');

  const prompt = `You are an expert productivity coach and schedule optimizer. Analyze this user's weekly schedule and provide detailed, actionable insights.

WEEK OF: ${weekStart}

SCHEDULED EVENTS:
${eventsText || 'No events scheduled'}

USER GOALS:
${goalsText || 'No goals set'}

DAILY HABITS:
${habitsText || 'No habits tracked'}

Please analyze this schedule and respond with a JSON object (no markdown, pure JSON) with this exact structure:
{
  "productivityScore": <integer 0-100>,
  "summary": "<2-3 sentence overall assessment>",
  "insights": ["<insight 1>", "<insight 2>", "<insight 3>"],
  "suggestions": ["<actionable suggestion 1>", "<suggestion 2>", "<suggestion 3>", "<suggestion 4>"],
  "timeBreakdown": [
    {"category": "Work", "hours": <number>, "percentage": <number>},
    {"category": "Personal", "hours": <number>, "percentage": <number>},
    {"category": "Health", "hours": <number>, "percentage": <number>},
    {"category": "Learning", "hours": <number>, "percentage": <number>}
  ],
  "overloadWarnings": ["<warning if any>"],
  "optimizations": ["<specific optimization tip 1>", "<tip 2>"]
}

Base the productivity score on: schedule balance, goal alignment, habit consistency, and workload distribution. Be specific and personalized.`;

  try {
    const result = await model.generateContent(prompt);
    const text = result.response.text().trim();
    
    // Clean JSON response
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (!jsonMatch) throw new Error('No JSON in response');
    
    const parsed = JSON.parse(jsonMatch[0]);
    return parsed as ScheduleAnalysis;
  } catch (error) {
    console.error('Gemini analysis error:', error);
    // Return a fallback response
    return {
      productivityScore: 65,
      summary: 'Unable to fully analyze your schedule at this time. Add more events and goals to get detailed insights.',
      insights: [
        'Your schedule data has been processed.',
        'Adding more events will improve analysis quality.',
        'Set specific goals with weekly hour targets for better recommendations.'
      ],
      suggestions: [
        'Block time for deep work in the morning hours',
        'Schedule breaks between intensive tasks',
        'Align your daily habits with your long-term goals',
        'Review your calendar weekly to adjust priorities'
      ],
      timeBreakdown: [
        { category: 'Work', hours: 0, percentage: 0 },
        { category: 'Personal', hours: 0, percentage: 0 },
        { category: 'Health', hours: 0, percentage: 0 },
        { category: 'Learning', hours: 0, percentage: 0 }
      ],
      overloadWarnings: [],
      optimizations: ['Start by scheduling your highest-priority tasks first thing in the morning.']
    };
  }
}

/**
 * Auto-schedule events based on a goal description
 */
export async function autoScheduleGoal(
  goalDescription: string,
  targetHours: number,
  existingEvents: any[],
  weekStart: string
): Promise<AutoScheduleResult> {
  const model = getModel();

  const existingText = existingEvents.map(e =>
    `- ${e.title}: ${new Date(e.start_time).toLocaleString()} to ${new Date(e.end_time).toLocaleString()}`
  ).join('\n');

  const weekStartDate = new Date(weekStart);
  const weekDays = Array.from({ length: 7 }, (_, i) => {
    const d = new Date(weekStartDate);
    d.setDate(d.getDate() + i);
    return d.toISOString().split('T')[0];
  });

  const prompt = `You are an expert AI scheduling assistant. Create an optimized schedule for this goal.

GOAL: "${goalDescription}"
TARGET HOURS THIS WEEK: ${targetHours} hours
WEEK: ${weekDays[0]} to ${weekDays[6]}

EXISTING EVENTS (DO NOT OVERLAP):
${existingText || 'None'}

Create a schedule that:
1. Distributes the ${targetHours} hours across optimal times
2. Places deep focus work in morning hours (8am-12pm) when possible
3. Avoids existing event conflicts
4. Keeps sessions to 1.5-3 hour blocks with breaks
5. Accounts for weekends having more flexibility

Respond with pure JSON (no markdown):
{
  "scheduledEvents": [
    {
      "title": "<specific session title>",
      "start_time": "<ISO 8601 datetime>",
      "end_time": "<ISO 8601 datetime>",
      "description": "<brief description of what to accomplish>",
      "category": "<work|study|fitness|personal>"
    }
  ],
  "explanation": "<2-3 sentences explaining the scheduling strategy>",
  "totalHoursScheduled": <number>
}`;

  try {
    const result = await model.generateContent(prompt);
    const text = result.response.text().trim();
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (!jsonMatch) throw new Error('No JSON in response');
    return JSON.parse(jsonMatch[0]) as AutoScheduleResult;
  } catch (error) {
    console.error('Auto-schedule error:', error);
    throw new Error('Failed to generate schedule. Please try again.');
  }
}

/**
 * Generate a quick AI suggestion for a single event
 */
export async function getEventSuggestion(event: any, userContext: any): Promise<string> {
  const model = getModel();
  
  const prompt = `A user just added this calendar event: "${event.title}" on ${new Date(event.start_time).toLocaleString()} for ${event.category} category.

Give one short, specific, actionable tip (2 sentences max) to help them be most productive during or around this event. Be conversational and helpful.`;

  try {
    const result = await model.generateContent(prompt);
    return result.response.text().trim();
  } catch {
    return 'Tip: Set a clear goal for this event before it starts, and prepare any materials you\'ll need in advance.';
  }
}
