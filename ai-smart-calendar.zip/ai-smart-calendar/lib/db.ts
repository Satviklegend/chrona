import { Pool } from 'pg';

// Connection pool for PostgreSQL (Neon)
let pool: Pool | null = null;

export function getPool(): Pool {
  if (!pool) {
    pool = new Pool({
      connectionString: process.env.DATABASE_URL,
      ssl: {
        rejectUnauthorized: false
      },
      max: 10,
      idleTimeoutMillis: 30000,
      connectionTimeoutMillis: 10000,
    });

    pool.on('error', (err) => {
      console.error('Unexpected error on idle client', err);
    });
  }
  return pool;
}

export async function query<T = any>(text: string, params?: any[]): Promise<{ rows: T[]; rowCount: number }> {
  const db = getPool();
  const start = Date.now();
  try {
    const res = await db.query(text, params);
    const duration = Date.now() - start;
    if (process.env.NODE_ENV === 'development') {
      console.log('Query executed', { text: text.substring(0, 100), duration, rows: res.rowCount });
    }
    return { rows: res.rows, rowCount: res.rowCount || 0 };
  } catch (error: any) {
    console.error('Database query error:', error.message);
    throw error;
  }
}

export async function getClient() {
  const db = getPool();
  const client = await db.connect();
  const originalQuery = client.query.bind(client);
  const release = client.release.bind(client);

  // Override release to catch double-releases
  (client as any).release = () => {
    (client as any).release = () => {
      console.error('Client released twice');
    };
    return release();
  };

  return client;
}
