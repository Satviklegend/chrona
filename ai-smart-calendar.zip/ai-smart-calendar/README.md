# 🚀 AI Smart Calendar

A full-stack AI-powered scheduling and productivity application built with Next.js, PostgreSQL (Neon), and Google Gemini AI.

---

## ✨ Features

- **JWT Authentication** — Secure signup/login with httpOnly cookies
- **Interactive Calendar** — Day, Week, Month views with event management
- **AI Schedule Analysis** — Gemini AI analyzes your week and gives a productivity score (0-100)
- **Auto-Scheduling** — Tell AI your goal + hours, it builds your schedule automatically
- **Goals Tracking** — Short/long-term goals with progress tracking
- **Habits Tracker** — Daily/weekly habits with streak counting
- **AI Insights Dashboard** — Charts, suggestions, time breakdowns
- **Dark Mode UI** — Beautiful neon-accented dark theme

---

## 🛠 Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | Next.js 14 (App Router), React 18, Tailwind CSS |
| Backend | Next.js API Routes (Node.js) |
| Database | PostgreSQL via Neon (serverless) |
| AI | Google Gemini 1.5 Flash |
| Auth | JWT + bcrypt + httpOnly cookies |
| Charts | Recharts |
| Animations | Framer Motion |

---

## ⚡ Quick Start

### 1. Clone and install

```bash
git clone <your-repo>
cd ai-smart-calendar
npm install
```

### 2. Environment variables

Copy `.env.local` — it's already pre-configured with your credentials:

```env
DATABASE_URL=postgresql://neondb_owner:npg_qps9HyE8kMSu@ep-solitary-river-anuw0ia6-pooler.c-6.us-east-1.aws.neon.tech/neondb?sslmode=require&channel_binding=require
JWT_SECRET=chrona-ai-super-secret-jwt-key-2024-change-in-production
GEMINI_API_KEY=AIzaSyA3VbDMxSnlZB4HrzCXEx4M0f1BSqB8ex8
NEXT_PUBLIC_APP_URL=http://localhost:3000
```

> ⚠️ **For production**: Change `JWT_SECRET` to a random 64-character string.

### 3. Run database migrations

```bash
npm run db:migrate
```

This creates all tables: `users`, `events`, `goals`, `habits`, `ai_insights`, `priorities`.

### 4. Start the development server

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000)

---

## 🏗 Project Structure

```
ai-smart-calendar/
├── app/
│   ├── page.tsx                    # Landing page
│   ├── layout.tsx                  # Root layout
│   ├── auth/page.tsx               # Login/Signup
│   ├── dashboard/
│   │   ├── layout.tsx              # Dashboard shell (sidebar + topbar)
│   │   ├── page.tsx                # Overview
│   │   ├── calendar/page.tsx       # Full calendar with day/week/month
│   │   ├── insights/page.tsx       # AI analysis dashboard
│   │   ├── goals/page.tsx          # Goals management
│   │   ├── habits/page.tsx         # Habits tracker
│   │   └── autoschedule/page.tsx   # AI auto-scheduling
│   └── api/
│       ├── auth/                   # signup, login, logout, me
│       ├── events/                 # CRUD events
│       ├── goals/                  # CRUD goals
│       ├── habits/                 # CRUD habits
│       └── ai/                     # analyze, autoschedule, insights
├── components/
│   └── dashboard/
│       ├── Sidebar.tsx
│       └── TopBar.tsx
├── lib/
│   ├── db.ts                       # PostgreSQL connection pool
│   ├── auth.ts                     # JWT utils, bcrypt
│   └── gemini.ts                   # Gemini AI integration
├── types/index.ts                  # TypeScript types
├── styles/globals.css              # Global CSS + design system
└── scripts/migrate.js              # DB migration script
```

---

## 🧠 AI Integration Details

### Schedule Analysis Prompt
```
Analyze this user's weekly schedule and provide insights:
- Productivity score (0-100)
- Weekly summary
- Key insights (3 bullets)
- Actionable suggestions (4 bullets)
- Time breakdown by category
- Overload warnings
- Optimization tips
```

### Auto-Schedule Prompt
```
Goal: "[user goal]"
Target: X hours this week
Existing events: [list of booked slots]

Create a schedule that:
1. Places deep work in 9am-12pm blocks
2. Avoids all existing event conflicts
3. Uses 1.5-3 hour focused sessions
4. Distributes evenly across the week
```

---

## 🚀 Deploy to Vercel (Production)

```bash
npm install -g vercel
vercel --prod
```

Set these environment variables in Vercel dashboard:
- `DATABASE_URL`
- `JWT_SECRET` (use a new strong secret)
- `GEMINI_API_KEY`
- `NEXT_PUBLIC_APP_URL` (your production URL)

---

## 📦 Available Scripts

```bash
npm run dev          # Start development server
npm run build        # Build for production
npm run start        # Start production server
npm run db:migrate   # Run database migrations
npm run lint         # Lint code
```

---

## 🔐 Security Notes

1. Change `JWT_SECRET` before going to production
2. The database URL contains credentials — never commit to public repos
3. API routes validate JWT on every request
4. Passwords are hashed with bcrypt (12 rounds)

---

## 📈 Scaling for 1M+ Users

This architecture is production-ready:
- **Neon PostgreSQL** — serverless, auto-scales, connection pooling built-in
- **Next.js API routes** — deploy to Vercel Edge for global distribution
- **Stateless JWT** — no server-side session storage needed
- **Connection pooling** — pg Pool with max 10 connections per instance
- **Indexed queries** — all user_id and time-based queries use indexes

For 1M users, add:
- Redis for caching frequent AI results
- Rate limiting on AI endpoints (per user/hour)
- Background job queue (Inngest/Trigger.dev) for async AI analysis

---

Built with ❤️ using Next.js, Neon PostgreSQL, and Google Gemini AI
