import { NextRequest, NextResponse } from 'next/server';
import { getUserFromRequest } from '@/lib/auth';
import { query } from '@/lib/db';

export async function PUT(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const payload = getUserFromRequest(req);
    if (!payload) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const { title, description, type, targetDate, progress, status, weeklyHours, category } = await req.json();

    const result = await query(
      `UPDATE goals SET title=$1, description=$2, type=$3, target_date=$4, progress=$5, status=$6, weekly_hours=$7, category=$8
       WHERE id=$9 AND user_id=$10 RETURNING *`,
      [title, description, type, targetDate, progress, status, weeklyHours, category, params.id, payload.userId]
    );

    if (result.rows.length === 0) return NextResponse.json({ error: 'Goal not found' }, { status: 404 });

    const row = result.rows[0];
    return NextResponse.json({
      id: row.id, userId: row.user_id, title: row.title, description: row.description,
      type: row.type, targetDate: row.target_date, progress: row.progress, status: row.status,
      weeklyHours: row.weekly_hours, category: row.category, createdAt: row.created_at,
    });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to update goal' }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const payload = getUserFromRequest(req);
    if (!payload) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    await query('DELETE FROM goals WHERE id=$1 AND user_id=$2', [params.id, payload.userId]);
    return NextResponse.json({ message: 'Goal deleted' });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to delete goal' }, { status: 500 });
  }
}
