import { NextRequest, NextResponse } from 'next/server';
import { getUserFromRequest } from '@/lib/auth';
import { query } from '@/lib/db';

function formatGoal(row: any) {
  return {
    id: row.id,
    userId: row.user_id,
    title: row.title,
    description: row.description,
    type: row.type,
    targetDate: row.target_date,
    progress: row.progress,
    status: row.status,
    weeklyHours: row.weekly_hours,
    category: row.category,
    createdAt: row.created_at,
  };
}

export async function GET(req: NextRequest) {
  try {
    const payload = getUserFromRequest(req);
    if (!payload) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const result = await query(
      'SELECT * FROM goals WHERE user_id=$1 ORDER BY created_at DESC',
      [payload.userId]
    );

    return NextResponse.json(result.rows.map(formatGoal));
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch goals' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const payload = getUserFromRequest(req);
    if (!payload) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const { title, description, type, targetDate, weeklyHours, category } = await req.json();

    if (!title) return NextResponse.json({ error: 'Title is required' }, { status: 400 });

    const result = await query(
      `INSERT INTO goals (user_id, title, description, type, target_date, weekly_hours, category)
       VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING *`,
      [payload.userId, title, description || null, type || 'short_term', targetDate || null, weeklyHours || null, category || null]
    );

    return NextResponse.json(formatGoal(result.rows[0]), { status: 201 });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to create goal' }, { status: 500 });
  }
}
