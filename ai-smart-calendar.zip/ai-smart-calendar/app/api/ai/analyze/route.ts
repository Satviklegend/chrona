import { NextRequest, NextResponse } from 'next/server';
import { getUserFromRequest } from '@/lib/auth';
import { query } from '@/lib/db';
import { analyzeSchedule } from '@/lib/gemini';
import { startOfWeek, endOfWeek, format } from 'date-fns';

export async function POST(req: NextRequest) {
  try {
    const payload = getUserFromRequest(req);
    if (!payload) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json().catch(() => ({}));
    const weekDate = body.weekDate ? new Date(body.weekDate) : new Date();
    
    const weekStart = startOfWeek(weekDate, { weekStartsOn: 1 });
    const weekEnd = endOfWeek(weekDate, { weekStartsOn: 1 });

    // Fetch events, goals, and habits for analysis
    const [eventsResult, goalsResult, habitsResult] = await Promise.all([
      query(
        'SELECT * FROM events WHERE user_id=$1 AND start_time >= $2 AND start_time <= $3 ORDER BY start_time',
        [payload.userId, weekStart.toISOString(), weekEnd.toISOString()]
      ),
      query('SELECT * FROM goals WHERE user_id=$1 AND status=\'active\'', [payload.userId]),
      query('SELECT * FROM habits WHERE user_id=$1 AND is_active=true', [payload.userId]),
    ]);

    const weekStartStr = format(weekStart, 'MMMM d, yyyy');

    // Call Gemini AI for analysis
    const analysis = await analyzeSchedule(
      eventsResult.rows,
      goalsResult.rows,
      habitsResult.rows,
      weekStartStr
    );

    // Save insight to database
    await query(
      `INSERT INTO ai_insights (user_id, type, title, content, data, productivity_score, week_start)
       VALUES ($1, $2, $3, $4, $5, $6, $7)`,
      [
        payload.userId,
        'weekly_analysis',
        `Week of ${weekStartStr}`,
        analysis.summary,
        JSON.stringify(analysis),
        analysis.productivityScore,
        format(weekStart, 'yyyy-MM-dd'),
      ]
    );

    return NextResponse.json(analysis);
  } catch (error: any) {
    console.error('AI analyze error:', error);
    return NextResponse.json({ error: error.message || 'Analysis failed' }, { status: 500 });
  }
}
