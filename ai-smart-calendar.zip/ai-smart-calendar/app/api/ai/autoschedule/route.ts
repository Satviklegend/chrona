import { NextRequest, NextResponse } from 'next/server';
import { getUserFromRequest } from '@/lib/auth';
import { query } from '@/lib/db';
import { autoScheduleGoal } from '@/lib/gemini';
import { CATEGORY_COLORS } from '@/types';
import { startOfWeek, format } from 'date-fns';

export async function POST(req: NextRequest) {
  try {
    const payload = getUserFromRequest(req);
    if (!payload) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const { goalDescription, targetHours, weekDate, autoAdd } = await req.json();

    if (!goalDescription || !targetHours) {
      return NextResponse.json({ error: 'Goal description and target hours are required' }, { status: 400 });
    }

    const weekStart = startOfWeek(weekDate ? new Date(weekDate) : new Date(), { weekStartsOn: 1 });
    const weekEnd = new Date(weekStart);
    weekEnd.setDate(weekEnd.getDate() + 7);

    // Fetch existing events to avoid conflicts
    const existingEvents = await query(
      'SELECT * FROM events WHERE user_id=$1 AND start_time >= $2 AND start_time <= $3',
      [payload.userId, weekStart.toISOString(), weekEnd.toISOString()]
    );

    // Call Gemini AI to auto-schedule
    const result = await autoScheduleGoal(
      goalDescription,
      parseFloat(targetHours),
      existingEvents.rows,
      format(weekStart, 'yyyy-MM-dd')
    );

    // If autoAdd is true, save events to DB
    if (autoAdd && result.scheduledEvents?.length > 0) {
      for (const event of result.scheduledEvents) {
        const color = CATEGORY_COLORS[event.category as keyof typeof CATEGORY_COLORS] || '#0ea5e9';
        await query(
          `INSERT INTO events (user_id, title, description, start_time, end_time, category, color, priority)
           VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
          [payload.userId, event.title, event.description, event.start_time, event.end_time, event.category, color, 'high']
        );
      }
    }

    return NextResponse.json(result);
  } catch (error: any) {
    console.error('Auto-schedule error:', error);
    return NextResponse.json({ error: error.message || 'Auto-scheduling failed' }, { status: 500 });
  }
}
