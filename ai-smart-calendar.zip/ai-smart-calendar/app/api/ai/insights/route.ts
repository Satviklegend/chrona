import { NextRequest, NextResponse } from 'next/server';
import { getUserFromRequest } from '@/lib/auth';
import { query } from '@/lib/db';

export async function GET(req: NextRequest) {
  try {
    const payload = getUserFromRequest(req);
    if (!payload) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const result = await query(
      'SELECT * FROM ai_insights WHERE user_id=$1 ORDER BY created_at DESC LIMIT 10',
      [payload.userId]
    );

    return NextResponse.json(result.rows.map(row => ({
      id: row.id,
      type: row.type,
      title: row.title,
      content: row.content,
      data: row.data,
      productivityScore: row.productivity_score,
      weekStart: row.week_start,
      createdAt: row.created_at,
    })));
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch insights' }, { status: 500 });
  }
}
