import { NextRequest, NextResponse } from 'next/server';
import { getUserFromRequest } from '@/lib/auth';
import { query } from '@/lib/db';

function formatHabit(row: any) {
  return {
    id: row.id, userId: row.user_id, title: row.title, description: row.description,
    frequency: row.frequency, targetTime: row.target_time, durationMinutes: row.duration_minutes,
    category: row.category, streak: row.streak, isActive: row.is_active, createdAt: row.created_at,
  };
}

export async function GET(req: NextRequest) {
  try {
    const payload = getUserFromRequest(req);
    if (!payload) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const result = await query('SELECT * FROM habits WHERE user_id=$1 AND is_active=true ORDER BY created_at DESC', [payload.userId]);
    return NextResponse.json(result.rows.map(formatHabit));
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch habits' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const payload = getUserFromRequest(req);
    if (!payload) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const { title, description, frequency, targetTime, durationMinutes, category } = await req.json();
    if (!title) return NextResponse.json({ error: 'Title is required' }, { status: 400 });

    const result = await query(
      `INSERT INTO habits (user_id, title, description, frequency, target_time, duration_minutes, category)
       VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING *`,
      [payload.userId, title, description || null, frequency || 'daily', targetTime || null, durationMinutes || 30, category || null]
    );

    return NextResponse.json(formatHabit(result.rows[0]), { status: 201 });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to create habit' }, { status: 500 });
  }
}
