import { NextRequest, NextResponse } from 'next/server';
import { getUserFromRequest } from '@/lib/auth';
import { query } from '@/lib/db';
import { CATEGORY_COLORS } from '@/types';

export async function PUT(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const payload = getUserFromRequest(req);
    if (!payload) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const { title, description, startTime, endTime, category, priority, location } = await req.json();
    const color = CATEGORY_COLORS[category as keyof typeof CATEGORY_COLORS] || '#0ea5e9';

    const result = await query(
      `UPDATE events 
       SET title=$1, description=$2, start_time=$3, end_time=$4, category=$5, color=$6, priority=$7, location=$8
       WHERE id=$9 AND user_id=$10
       RETURNING *`,
      [title, description, startTime, endTime, category, color, priority, location, params.id, payload.userId]
    );

    if (result.rows.length === 0) {
      return NextResponse.json({ error: 'Event not found' }, { status: 404 });
    }

    const row = result.rows[0];
    return NextResponse.json({
      id: row.id,
      userId: row.user_id,
      title: row.title,
      description: row.description,
      startTime: row.start_time,
      endTime: row.end_time,
      category: row.category,
      color: row.color,
      priority: row.priority,
      location: row.location,
      createdAt: row.created_at,
    });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to update event' }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const payload = getUserFromRequest(req);
    if (!payload) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const result = await query(
      'DELETE FROM events WHERE id=$1 AND user_id=$2 RETURNING id',
      [params.id, payload.userId]
    );

    if (result.rows.length === 0) {
      return NextResponse.json({ error: 'Event not found' }, { status: 404 });
    }

    return NextResponse.json({ message: 'Event deleted' });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to delete event' }, { status: 500 });
  }
}
