import { NextRequest, NextResponse } from 'next/server';
import { getUserFromRequest } from '@/lib/auth';
import { query } from '@/lib/db';
import { CATEGORY_COLORS } from '@/types';

function formatEvent(row: any) {
  return {
    id: row.id,
    userId: row.user_id,
    title: row.title,
    description: row.description,
    startTime: row.start_time,
    endTime: row.end_time,
    category: row.category,
    color: row.color,
    priority: row.priority,
    isRecurring: row.is_recurring,
    location: row.location,
    createdAt: row.created_at,
  };
}

export async function GET(req: NextRequest) {
  try {
    const payload = getUserFromRequest(req);
    if (!payload) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const { searchParams } = new URL(req.url);
    const startDate = searchParams.get('start');
    const endDate = searchParams.get('end');

    let queryText = 'SELECT * FROM events WHERE user_id = $1';
    const params: any[] = [payload.userId];

    if (startDate && endDate) {
      queryText += ' AND start_time >= $2 AND start_time <= $3';
      params.push(startDate, endDate);
    }

    queryText += ' ORDER BY start_time ASC';

    const result = await query(queryText, params);
    return NextResponse.json(result.rows.map(formatEvent));
  } catch (error) {
    console.error('GET events error:', error);
    return NextResponse.json({ error: 'Failed to fetch events' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const payload = getUserFromRequest(req);
    if (!payload) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const { title, description, startTime, endTime, category, priority, location } = await req.json();

    if (!title || !startTime || !endTime) {
      return NextResponse.json({ error: 'Title, start time, and end time are required' }, { status: 400 });
    }

    const color = CATEGORY_COLORS[category as keyof typeof CATEGORY_COLORS] || '#0ea5e9';

    const result = await query(
      `INSERT INTO events (user_id, title, description, start_time, end_time, category, color, priority, location)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
       RETURNING *`,
      [payload.userId, title, description || null, startTime, endTime, category || 'personal', color, priority || 'medium', location || null]
    );

    return NextResponse.json(formatEvent(result.rows[0]), { status: 201 });
  } catch (error) {
    console.error('POST events error:', error);
    return NextResponse.json({ error: 'Failed to create event' }, { status: 500 });
  }
}
