import { NextRequest, NextResponse } from 'next/server';
import { query } from '@/lib/db';
import { hashPassword, signToken, cookieOptions } from '@/lib/auth';

export async function POST(req: NextRequest) {
  try {
    const { name, email, password } = await req.json();

    // Validation
    if (!name || !email || !password) {
      return NextResponse.json({ error: 'All fields are required' }, { status: 400 });
    }

    if (password.length < 8) {
      return NextResponse.json({ error: 'Password must be at least 8 characters' }, { status: 400 });
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return NextResponse.json({ error: 'Invalid email address' }, { status: 400 });
    }

    // Check if user exists
    const existing = await query('SELECT id FROM users WHERE email = $1', [email.toLowerCase()]);
    if (existing.rows.length > 0) {
      return NextResponse.json({ error: 'Email already registered' }, { status: 409 });
    }

    // Hash password and create user
    const passwordHash = await hashPassword(password);
    const avatarColors = ['#0ea5e9', '#8b5cf6', '#10b981', '#f59e0b', '#ec4899', '#06b6d4'];
    const avatarColor = avatarColors[Math.floor(Math.random() * avatarColors.length)];

    const result = await query(
      `INSERT INTO users (name, email, password_hash, avatar_color) 
       VALUES ($1, $2, $3, $4) 
       RETURNING id, name, email, avatar_color, timezone, created_at`,
      [name.trim(), email.toLowerCase(), passwordHash, avatarColor]
    );

    const user = result.rows[0];
    const token = signToken({ userId: user.id, email: user.email, name: user.name });

    const response = NextResponse.json({
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        avatarColor: user.avatar_color,
        timezone: user.timezone,
        createdAt: user.created_at,
      },
      token,
    }, { status: 201 });

    response.cookies.set('auth_token', token, cookieOptions);
    return response;

  } catch (error: any) {
    console.error('Signup error:', error);
    return NextResponse.json({ error: 'Failed to create account' }, { status: 500 });
  }
}
