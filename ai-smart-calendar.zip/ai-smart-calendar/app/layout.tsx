import type { Metadata, Viewport } from 'next';
import { Outfit } from 'next/font/google';
import '../styles/globals.css';
import { Toaster } from 'react-hot-toast';

const outfit = Outfit({
  subsets: ['latin'],
  variable: '--font-inter',
  display: 'swap',
});

export const metadata: Metadata = {
  title: 'AI Smart Calendar — Your Intelligent Scheduling Assistant',
  description: 'AI-powered scheduling and productivity platform. Analyze your schedule, get smart suggestions, and auto-schedule your goals with cutting-edge AI.',
  keywords: ['AI calendar', 'smart scheduling', 'productivity', 'time management', 'AI assistant'],
  authors: [{ name: 'AI Smart Calendar' }],
  openGraph: {
    title: 'AI Smart Calendar',
    description: 'Your intelligent scheduling and productivity assistant powered by AI',
    type: 'website',
  },
};

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  themeColor: '#0a0a0f',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark">
      <body className={`${outfit.variable} antialiased`}>
        {children}
        <Toaster
          position="top-right"
          toastOptions={{
            style: {
              background: '#16161f',
              color: '#f0f0f8',
              border: '1px solid rgba(255,255,255,0.08)',
              borderRadius: '12px',
              fontFamily: 'Outfit, sans-serif',
              fontSize: '14px',
            },
            success: {
              iconTheme: { primary: '#34d399', secondary: '#16161f' },
            },
            error: {
              iconTheme: { primary: '#f87171', secondary: '#16161f' },
            },
          }}
        />
      </body>
    </html>
  );
}
