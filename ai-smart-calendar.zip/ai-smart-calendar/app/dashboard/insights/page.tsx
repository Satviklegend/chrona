'use client';
import { useState, useEffect } from 'react';
import { format, startOfWeek } from 'date-fns';
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid } from 'recharts';
import toast from 'react-hot-toast';

const COLORS = ['#4f9cf9', '#a78bfa', '#34d399', '#f59e0b', '#f472b6', '#22d3ee'];

function ScoreRing({ score }: { score: number }) {
  const r = 70;
  const circ = 2 * Math.PI * r;
  const pct = (score / 100) * circ;
  const color = score >= 80 ? '#34d399' : score >= 60 ? '#4f9cf9' : score >= 40 ? '#f59e0b' : '#ef4444';
  
  return (
    <div className="relative inline-flex items-center justify-center">
      <svg width="180" height="180">
        <circle cx="90" cy="90" r={r} fill="none" stroke="rgba(255,255,255,0.05)" strokeWidth="12" />
        <circle cx="90" cy="90" r={r} fill="none" stroke={color}
          strokeWidth="12" strokeDasharray={`${pct} ${circ}`}
          strokeLinecap="round" transform="rotate(-90 90 90)"
          style={{ transition: 'stroke-dasharray 1s ease', filter: `drop-shadow(0 0 8px ${color})` }} />
      </svg>
      <div className="absolute text-center">
        <div className="text-5xl font-extrabold" style={{ color }}>{score}</div>
        <div className="text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>/ 100</div>
      </div>
    </div>
  );
}

export default function InsightsPage() {
  const [loading, setLoading] = useState(false);
  const [analysis, setAnalysis] = useState<any>(null);
  const [pastInsights, setPastInsights] = useState<any[]>([]);
  const [loadingHistory, setLoadingHistory] = useState(true);

  const authHeaders = () => ({
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${localStorage.getItem('auth_token')}`,
  });

  useEffect(() => {
    loadHistory();
  }, []);

  const loadHistory = async () => {
    try {
      const res = await fetch('/api/ai/insights', { headers: authHeaders() });
      const data = await res.json();
      if (Array.isArray(data) && data.length > 0) {
        setPastInsights(data);
        // Show latest insight
        const latest = data[0];
        if (latest.data) {
          setAnalysis(typeof latest.data === 'string' ? JSON.parse(latest.data) : latest.data);
        }
      }
    } finally {
      setLoadingHistory(false);
    }
  };

  const runAnalysis = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/ai/analyze', {
        method: 'POST',
        headers: authHeaders(),
        body: JSON.stringify({ weekDate: new Date().toISOString() }),
      });

      if (!res.ok) throw new Error('Analysis failed');
      const data = await res.json();
      setAnalysis(data);
      toast.success('AI analysis complete! 🧠');
      loadHistory();
    } catch (error: any) {
      toast.error(error.message || 'Analysis failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const weekLabel = format(startOfWeek(new Date(), { weekStartsOn: 1 }), 'MMM d') + ' – ' + format(new Date(), 'MMM d, yyyy');

  return (
    <div className="max-w-6xl mx-auto space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold" style={{ color: 'var(--text-primary)' }}>AI Insights</h1>
          <p className="text-sm mt-1" style={{ color: 'var(--text-secondary)' }}>Week of {weekLabel}</p>
        </div>
        <button onClick={runAnalysis} disabled={loading}
          className="btn-primary py-3 px-6 rounded-xl flex items-center gap-2">
          {loading ? (
            <>
              <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              Analyzing...
            </>
          ) : '🧠 Analyze This Week'}
        </button>
      </div>

      {!analysis && !loadingHistory && (
        <div className="card text-center py-20">
          <div className="text-6xl mb-4">🧠</div>
          <h2 className="text-xl font-bold mb-2" style={{ color: 'var(--text-primary)' }}>No Analysis Yet</h2>
          <p className="mb-6 max-w-md mx-auto" style={{ color: 'var(--text-secondary)' }}>
            Click "Analyze This Week" to get AI-powered insights about your schedule, productivity score, and personalized improvement suggestions.
          </p>
          <button onClick={runAnalysis} disabled={loading} className="btn-primary py-3 px-8 rounded-xl">
            🚀 Run My First Analysis
          </button>
        </div>
      )}

      {loadingHistory && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {[...Array(6)].map((_, i) => <div key={i} className="h-40 rounded-2xl shimmer" />)}
        </div>
      )}

      {analysis && (
        <>
          {/* Score + Summary */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="card flex flex-col items-center justify-center py-8"
              style={{ borderColor: 'rgba(79,156,249,0.2)', background: 'rgba(79,156,249,0.03)' }}>
              <div className="text-sm font-semibold mb-4" style={{ color: 'var(--text-secondary)' }}>Productivity Score</div>
              <ScoreRing score={analysis.productivityScore || 0} />
              <div className="mt-4 text-center">
                <div className="text-sm font-medium" style={{
                  color: (analysis.productivityScore || 0) >= 80 ? '#34d399' : (analysis.productivityScore || 0) >= 60 ? '#4f9cf9' : '#f59e0b'
                }}>
                  {(analysis.productivityScore || 0) >= 80 ? '🔥 Excellent' : (analysis.productivityScore || 0) >= 60 ? '📈 Good' : '📉 Needs Work'}
                </div>
              </div>
            </div>

            <div className="lg:col-span-2 card">
              <h3 className="font-bold mb-3" style={{ color: 'var(--text-primary)' }}>📋 Weekly Summary</h3>
              <p className="text-sm leading-relaxed mb-4" style={{ color: 'var(--text-secondary)' }}>
                {analysis.summary}
              </p>
              {analysis.overloadWarnings?.length > 0 && (
                <div className="space-y-2">
                  {analysis.overloadWarnings.map((w: string, i: number) => (
                    <div key={i} className="flex items-start gap-2 p-3 rounded-xl text-sm"
                      style={{ background: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.2)', color: '#f87171' }}>
                      ⚠️ {w}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Charts row */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Time breakdown pie chart */}
            {analysis.timeBreakdown?.length > 0 && (
              <div className="card">
                <h3 className="font-bold mb-4" style={{ color: 'var(--text-primary)' }}>📊 Time Breakdown</h3>
                <div className="flex items-center gap-6">
                  <ResponsiveContainer width={180} height={180}>
                    <PieChart>
                      <Pie data={analysis.timeBreakdown} dataKey="hours" cx="50%" cy="50%" innerRadius={50} outerRadius={80}>
                        {analysis.timeBreakdown.map((_: any, i: number) => (
                          <Cell key={i} fill={COLORS[i % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip
                        contentStyle={{ background: 'var(--bg-elevated)', border: '1px solid var(--border)', borderRadius: '10px', color: 'var(--text-primary)' }}
                        formatter={(value: any) => [`${value}h`, '']} />
                    </PieChart>
                  </ResponsiveContainer>
                  <div className="flex-1 space-y-2">
                    {analysis.timeBreakdown.map((item: any, i: number) => (
                      <div key={item.category} className="flex items-center gap-2">
                        <div className="w-3 h-3 rounded-full flex-shrink-0" style={{ background: COLORS[i % COLORS.length] }} />
                        <span className="text-sm flex-1" style={{ color: 'var(--text-secondary)' }}>{item.category}</span>
                        <span className="text-sm font-semibold" style={{ color: 'var(--text-primary)' }}>{item.hours}h</span>
                        <span className="text-xs" style={{ color: 'var(--text-muted)' }}>{item.percentage}%</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* AI Insights list */}
            <div className="card">
              <h3 className="font-bold mb-4" style={{ color: 'var(--text-primary)' }}>💡 Key Insights</h3>
              <div className="space-y-3">
                {analysis.insights?.map((insight: string, i: number) => (
                  <div key={i} className="flex items-start gap-3 p-3 rounded-xl"
                    style={{ background: 'var(--bg-elevated)' }}>
                    <span className="text-lg flex-shrink-0">
                      {i === 0 ? '🎯' : i === 1 ? '⚡' : i === 2 ? '📈' : '🔍'}
                    </span>
                    <p className="text-sm leading-relaxed" style={{ color: 'var(--text-secondary)' }}>{insight}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Suggestions */}
          <div className="card">
            <h3 className="font-bold mb-4" style={{ color: 'var(--text-primary)' }}>🚀 AI Suggestions</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {analysis.suggestions?.map((suggestion: string, i: number) => (
                <div key={i} className="flex items-start gap-3 p-4 rounded-xl"
                  style={{ background: 'rgba(79,156,249,0.06)', border: '1px solid rgba(79,156,249,0.15)' }}>
                  <div className="w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 text-white"
                    style={{ background: '#4f9cf9' }}>
                    {i + 1}
                  </div>
                  <p className="text-sm leading-relaxed" style={{ color: 'var(--text-secondary)' }}>{suggestion}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Optimizations */}
          {analysis.optimizations?.length > 0 && (
            <div className="card">
              <h3 className="font-bold mb-4" style={{ color: 'var(--text-primary)' }}>⚙️ Optimizations</h3>
              <div className="space-y-2">
                {analysis.optimizations.map((opt: string, i: number) => (
                  <div key={i} className="flex items-start gap-2 text-sm" style={{ color: 'var(--text-secondary)' }}>
                    <span style={{ color: '#34d399' }}>→</span>
                    <span>{opt}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </>
      )}

      {/* Past analyses */}
      {pastInsights.length > 1 && (
        <div className="card">
          <h3 className="font-bold mb-4" style={{ color: 'var(--text-primary)' }}>📅 Analysis History</h3>
          <div className="space-y-3">
            {pastInsights.slice(0, 5).map((insight) => (
              <div key={insight.id} className="flex items-center justify-between p-4 rounded-xl"
                style={{ background: 'var(--bg-elevated)' }}>
                <div>
                  <div className="text-sm font-medium" style={{ color: 'var(--text-primary)' }}>{insight.title}</div>
                  <div className="text-xs mt-0.5" style={{ color: 'var(--text-muted)' }}>
                    {format(new Date(insight.createdAt), 'MMM d, yyyy h:mm a')}
                  </div>
                </div>
                {insight.productivityScore && (
                  <div className="text-2xl font-extrabold gradient-text">{insight.productivityScore}</div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
