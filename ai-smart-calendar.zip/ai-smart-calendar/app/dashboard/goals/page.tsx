'use client';
import { useState, useEffect } from 'react';
import { format } from 'date-fns';
import toast from 'react-hot-toast';

function GoalModal({ goal, onClose, onSave }: { goal?: any; onClose: () => void; onSave: (data: any) => void }) {
  const isEdit = !!goal?.id;
  const [form, setForm] = useState({
    title: goal?.title || '',
    description: goal?.description || '',
    type: goal?.type || 'short_term',
    targetDate: goal?.targetDate ? goal.targetDate.split('T')[0] : '',
    weeklyHours: goal?.weeklyHours || '',
    category: goal?.category || 'work',
    progress: goal?.progress || 0,
    status: goal?.status || 'active',
  });

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold" style={{ color: 'var(--text-primary)' }}>
            {isEdit ? 'Edit Goal' : '+ New Goal'}
          </h2>
          <button onClick={onClose} className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-white/10" style={{ color: 'var(--text-secondary)' }}>✕</button>
        </div>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text-secondary)' }}>Goal Title *</label>
            <input className="input" placeholder="e.g., Learn Spanish, Run 5K..." value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text-secondary)' }}>Type</label>
              <select className="input" value={form.type} onChange={e => setForm({ ...form, type: e.target.value })}>
                <option value="short_term">Short-term</option>
                <option value="long_term">Long-term</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text-secondary)' }}>Category</label>
              <select className="input" value={form.category} onChange={e => setForm({ ...form, category: e.target.value })}>
                {['work', 'health', 'learning', 'fitness', 'personal', 'finance', 'social', 'creative'].map(c => (
                  <option key={c} value={c}>{c.charAt(0).toUpperCase() + c.slice(1)}</option>
                ))}
              </select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text-secondary)' }}>Target Date</label>
              <input type="date" className="input" value={form.targetDate} onChange={e => setForm({ ...form, targetDate: e.target.value })} />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text-secondary)' }}>Weekly Hours</label>
              <input type="number" className="input" placeholder="e.g., 5" min="0" max="168" value={form.weeklyHours} onChange={e => setForm({ ...form, weeklyHours: e.target.value })} />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text-secondary)' }}>Description</label>
            <textarea className="input" rows={3} placeholder="What does success look like?" value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} />
          </div>
          {isEdit && (
            <div>
              <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text-secondary)' }}>
                Progress: {form.progress}%
              </label>
              <input type="range" min="0" max="100" value={form.progress}
                onChange={e => setForm({ ...form, progress: parseInt(e.target.value) })}
                className="w-full accent-blue-400" />
            </div>
          )}
        </div>
        <div className="flex gap-3 mt-6">
          <button onClick={onClose} className="btn-secondary flex-1 text-sm py-2.5 rounded-xl">Cancel</button>
          <button onClick={() => { if (!form.title) return toast.error('Title required'); onSave(form); onClose(); }}
            className="btn-primary flex-1 text-sm py-2.5 rounded-xl">
            {isEdit ? 'Save Changes' : 'Add Goal'}
          </button>
        </div>
      </div>
    </div>
  );
}

const categoryIcons: Record<string, string> = {
  work: '💼', health: '❤️', learning: '📚', fitness: '🏃', personal: '⭐', finance: '💰', social: '👥', creative: '🎨'
};

export default function GoalsPage() {
  const [goals, setGoals] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState<{ open: boolean; goal?: any }>({ open: false });
  const [filter, setFilter] = useState<'all' | 'active' | 'completed'>('all');

  const authHeaders = () => ({ 'Content-Type': 'application/json', 'Authorization': `Bearer ${localStorage.getItem('auth_token')}` });

  const loadGoals = async () => {
    try {
      const res = await fetch('/api/goals', { headers: authHeaders() });
      const data = await res.json();
      setGoals(Array.isArray(data) ? data : []);
    } finally { setLoading(false); }
  };

  useEffect(() => { loadGoals(); }, []);

  const saveGoal = async (formData: any) => {
    const isEdit = !!modal.goal?.id;
    try {
      const res = await fetch(isEdit ? `/api/goals/${modal.goal.id}` : '/api/goals', {
        method: isEdit ? 'PUT' : 'POST',
        headers: authHeaders(),
        body: JSON.stringify({
          title: formData.title, description: formData.description, type: formData.type,
          targetDate: formData.targetDate || null, weeklyHours: formData.weeklyHours ? parseFloat(formData.weeklyHours) : null,
          category: formData.category, progress: parseInt(formData.progress), status: formData.status,
        }),
      });
      if (!res.ok) throw new Error('Failed');
      toast.success(isEdit ? 'Goal updated! ✓' : 'Goal added! 🎯');
      loadGoals();
    } catch { toast.error('Failed to save goal'); }
  };

  const deleteGoal = async (id: string) => {
    if (!confirm('Delete this goal?')) return;
    await fetch(`/api/goals/${id}`, { method: 'DELETE', headers: authHeaders() });
    toast.success('Goal deleted');
    loadGoals();
  };

  const markComplete = async (goal: any) => {
    await fetch(`/api/goals/${goal.id}`, {
      method: 'PUT', headers: authHeaders(),
      body: JSON.stringify({ ...goal, progress: 100, status: 'completed' }),
    });
    toast.success('Goal completed! 🎉');
    loadGoals();
  };

  const filtered = goals.filter(g => filter === 'all' || g.status === filter);
  const stats = { total: goals.length, active: goals.filter(g => g.status === 'active').length, completed: goals.filter(g => g.status === 'completed').length };

  return (
    <div className="max-w-5xl mx-auto space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold" style={{ color: 'var(--text-primary)' }}>Goals</h1>
          <p className="text-sm mt-1" style={{ color: 'var(--text-secondary)' }}>Track your short and long-term objectives</p>
        </div>
        <button onClick={() => setModal({ open: true })} className="btn-primary py-2.5 px-5 rounded-xl text-sm">
          + Add Goal
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4">
        {[
          { label: 'Total Goals', value: stats.total, color: '#4f9cf9', icon: '🎯' },
          { label: 'Active', value: stats.active, color: '#a78bfa', icon: '🔥' },
          { label: 'Completed', value: stats.completed, color: '#34d399', icon: '✅' },
        ].map(s => (
          <div key={s.label} className="card text-center py-5">
            <div className="text-2xl mb-1">{s.icon}</div>
            <div className="text-3xl font-extrabold" style={{ color: s.color }}>{s.value}</div>
            <div className="text-xs mt-1" style={{ color: 'var(--text-muted)' }}>{s.label}</div>
          </div>
        ))}
      </div>

      {/* Filter tabs */}
      <div className="flex gap-2">
        {(['all', 'active', 'completed'] as const).map(f => (
          <button key={f} onClick={() => setFilter(f)}
            className={`text-sm font-medium py-2 px-5 rounded-xl transition-all capitalize ${filter === f ? 'text-white' : ''}`}
            style={{ background: filter === f ? '#4f9cf9' : 'var(--bg-elevated)', color: filter === f ? 'white' : 'var(--text-secondary)', border: '1px solid var(--border)' }}>
            {f}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="space-y-4">{[...Array(3)].map((_, i) => <div key={i} className="h-32 rounded-2xl shimmer" />)}</div>
      ) : filtered.length === 0 ? (
        <div className="card text-center py-16">
          <div className="text-5xl mb-3">🎯</div>
          <h3 className="font-bold text-lg mb-2" style={{ color: 'var(--text-primary)' }}>No goals yet</h3>
          <p className="text-sm mb-4" style={{ color: 'var(--text-secondary)' }}>Set your first goal to start tracking progress</p>
          <button onClick={() => setModal({ open: true })} className="btn-primary py-2.5 px-6 rounded-xl text-sm inline-block">
            Add Your First Goal
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {filtered.map(goal => {
            const isCompleted = goal.status === 'completed';
            return (
              <div key={goal.id} className={`card card-hover ${isCompleted ? 'opacity-70' : ''}`}>
                <div className="flex items-start gap-4">
                  <div className="text-3xl flex-shrink-0">{categoryIcons[goal.category] || '🎯'}</div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <h3 className={`font-bold text-base ${isCompleted ? 'line-through' : ''}`} style={{ color: 'var(--text-primary)' }}>
                          {goal.title}
                        </h3>
                        {goal.description && (
                          <p className="text-sm mt-0.5 truncate" style={{ color: 'var(--text-secondary)' }}>{goal.description}</p>
                        )}
                      </div>
                      <div className="flex items-center gap-2 flex-shrink-0">
                        <span className="badge text-xs"
                          style={{ background: goal.type === 'long_term' ? 'rgba(167,139,250,0.15)' : 'rgba(79,156,249,0.15)', color: goal.type === 'long_term' ? '#a78bfa' : '#4f9cf9' }}>
                          {goal.type === 'long_term' ? 'Long-term' : 'Short-term'}
                        </span>
                      </div>
                    </div>

                    <div className="flex flex-wrap gap-3 mt-3 text-xs" style={{ color: 'var(--text-muted)' }}>
                      {goal.targetDate && <span>📅 Due {format(new Date(goal.targetDate), 'MMM d, yyyy')}</span>}
                      {goal.weeklyHours && <span>⏱ {goal.weeklyHours}h/week</span>}
                      {goal.category && <span>🏷 {goal.category}</span>}
                    </div>

                    <div className="mt-3">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-xs" style={{ color: 'var(--text-muted)' }}>Progress</span>
                        <span className="text-xs font-semibold" style={{ color: 'var(--text-primary)' }}>{goal.progress}%</span>
                      </div>
                      <div className="progress-bar">
                        <div className="progress-fill" style={{ width: `${goal.progress}%` }} />
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 mt-4 pt-4" style={{ borderTop: '1px solid var(--border)' }}>
                  <button onClick={() => setModal({ open: true, goal })}
                    className="btn-secondary text-xs py-1.5 px-4 rounded-lg">Edit</button>
                  {!isCompleted && (
                    <button onClick={() => markComplete(goal)}
                      className="text-xs py-1.5 px-4 rounded-lg transition-colors"
                      style={{ background: 'rgba(52,211,153,0.1)', color: '#34d399', border: '1px solid rgba(52,211,153,0.2)' }}>
                      Mark Complete ✓
                    </button>
                  )}
                  <button onClick={() => deleteGoal(goal.id)}
                    className="text-xs py-1.5 px-4 rounded-lg transition-colors ml-auto"
                    style={{ background: 'rgba(239,68,68,0.1)', color: '#f87171', border: '1px solid rgba(239,68,68,0.2)' }}>
                    Delete
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {modal.open && (
        <GoalModal goal={modal.goal} onClose={() => setModal({ open: false })} onSave={saveGoal} />
      )}
    </div>
  );
}
