'use client';
import { useState } from 'react';
import { format } from 'date-fns';
import toast from 'react-hot-toast';
import { CATEGORY_COLORS } from '@/types';

const exampleGoals = [
  'Study Machine Learning 10 hours this week',
  'Work on side project 8 hours',
  'Exercise and gym sessions 5 hours',
  'Read books 3 hours this week',
  'Practice Spanish 4 hours',
  'Deep work on thesis 12 hours',
];

export default function AutoSchedulePage() {
  const [form, setForm] = useState({ goalDescription: '', targetHours: '', weekDate: new Date().toISOString().split('T')[0] });
  const [result, setResult] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [adding, setAdding] = useState(false);

  const authHeaders = () => ({ 'Content-Type': 'application/json', 'Authorization': `Bearer ${localStorage.getItem('auth_token')}` });

  const generateSchedule = async () => {
    if (!form.goalDescription || !form.targetHours) return toast.error('Please fill in all fields');
    if (parseFloat(form.targetHours) <= 0 || parseFloat(form.targetHours) > 80) return toast.error('Target hours must be between 1 and 80');

    setLoading(true);
    setResult(null);
    try {
      const res = await fetch('/api/ai/autoschedule', {
        method: 'POST', headers: authHeaders(),
        body: JSON.stringify({ goalDescription: form.goalDescription, targetHours: form.targetHours, weekDate: form.weekDate, autoAdd: false }),
      });
      if (!res.ok) throw new Error((await res.json()).error || 'Failed');
      const data = await res.json();
      setResult(data);
      toast.success(`AI scheduled ${data.totalHoursScheduled}h across ${data.scheduledEvents?.length} sessions! 🚀`);
    } catch (error: any) {
      toast.error(error.message || 'Scheduling failed. Please try again.');
    } finally { setLoading(false); }
  };

  const addToCalendar = async () => {
    if (!result) return;
    setAdding(true);
    try {
      const res = await fetch('/api/ai/autoschedule', {
        method: 'POST', headers: authHeaders(),
        body: JSON.stringify({ goalDescription: form.goalDescription, targetHours: form.targetHours, weekDate: form.weekDate, autoAdd: true }),
      });
      if (!res.ok) throw new Error('Failed to add events');
      toast.success(`${result.scheduledEvents?.length} events added to your calendar! 📅`);
      setResult(null);
      setForm({ goalDescription: '', targetHours: '', weekDate: new Date().toISOString().split('T')[0] });
    } catch (error: any) {
      toast.error(error.message);
    } finally { setAdding(false); }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 animate-fade-in">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold" style={{ color: 'var(--text-primary)' }}>Auto-Schedule</h1>
        <p className="text-sm mt-1" style={{ color: 'var(--text-secondary)' }}>
          Tell the AI your goal and it will automatically build the optimal schedule across your week
        </p>
      </div>

      {/* How it works banner */}
      <div className="card" style={{ background: 'linear-gradient(135deg, rgba(79,156,249,0.08), rgba(167,139,250,0.08))', borderColor: 'rgba(79,156,249,0.2)' }}>
        <div className="flex items-start gap-4">
          <div className="text-4xl">🤖</div>
          <div>
            <h3 className="font-bold mb-1" style={{ color: 'var(--text-primary)' }}>How it works</h3>
            <p className="text-sm leading-relaxed" style={{ color: 'var(--text-secondary)' }}>
              Gemini AI analyzes your existing events to avoid conflicts, then intelligently distributes your goal across
              optimal time slots — placing deep work in mornings, balancing session lengths, and respecting your schedule.
            </p>
          </div>
        </div>
      </div>

      {/* Input form */}
      <div className="card">
        <h2 className="font-bold text-lg mb-5" style={{ color: 'var(--text-primary)' }}>Define Your Goal</h2>
        <div className="space-y-5">
          <div>
            <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text-secondary)' }}>
              What do you want to achieve this week? *
            </label>
            <textarea className="input" rows={3}
              placeholder='e.g., "Study for machine learning exam 10 hours" or "Work on startup project 8 hours"'
              value={form.goalDescription} onChange={e => setForm({ ...form, goalDescription: e.target.value })} />
            {/* Example prompts */}
            <div className="flex flex-wrap gap-2 mt-2">
              {exampleGoals.map((eg, i) => (
                <button key={i} onClick={() => {
                  const parts = eg.match(/(\d+)\s*hours?/i);
                  setForm({ ...form, goalDescription: eg, targetHours: parts ? parts[1] : form.targetHours });
                }}
                  className="text-xs py-1 px-3 rounded-full transition-colors"
                  style={{ background: 'var(--bg-elevated)', color: 'var(--text-secondary)', border: '1px solid var(--border)' }}>
                  {eg.length > 40 ? eg.substring(0, 38) + '...' : eg}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text-secondary)' }}>
                Target Hours *
              </label>
              <input type="number" className="input" placeholder="e.g., 10" min="1" max="80" step="0.5"
                value={form.targetHours} onChange={e => setForm({ ...form, targetHours: e.target.value })} />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text-secondary)' }}>
                Week Starting
              </label>
              <input type="date" className="input" value={form.weekDate}
                onChange={e => setForm({ ...form, weekDate: e.target.value })} />
            </div>
          </div>

          <button onClick={generateSchedule} disabled={loading}
            className="btn-primary w-full py-3.5 rounded-xl text-base flex items-center justify-center gap-3">
            {loading ? (
              <>
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                AI is building your schedule...
              </>
            ) : '🚀 Generate AI Schedule'}
          </button>
        </div>
      </div>

      {/* Results */}
      {loading && (
        <div className="card text-center py-12">
          <div className="text-5xl mb-4 animate-spin-slow">🧠</div>
          <h3 className="font-bold text-lg mb-2" style={{ color: 'var(--text-primary)' }}>Analyzing your calendar...</h3>
          <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>
            Gemini AI is checking your existing events and building the optimal schedule
          </p>
        </div>
      )}

      {result && !loading && (
        <div className="space-y-4">
          {/* AI explanation */}
          <div className="card" style={{ background: 'rgba(167,139,250,0.06)', borderColor: 'rgba(167,139,250,0.2)' }}>
            <div className="flex items-start gap-3">
              <span className="text-2xl">🧠</span>
              <div>
                <h3 className="font-bold mb-1" style={{ color: '#a78bfa' }}>AI Strategy</h3>
                <p className="text-sm leading-relaxed" style={{ color: 'var(--text-secondary)' }}>{result.explanation}</p>
                <div className="flex items-center gap-4 mt-3 text-sm">
                  <span style={{ color: 'var(--text-muted)' }}>Total scheduled:</span>
                  <span className="font-bold" style={{ color: '#a78bfa' }}>{result.totalHoursScheduled}h</span>
                  <span style={{ color: 'var(--text-muted)' }}>Sessions:</span>
                  <span className="font-bold" style={{ color: '#a78bfa' }}>{result.scheduledEvents?.length}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Scheduled events preview */}
          <div className="card">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold text-lg" style={{ color: 'var(--text-primary)' }}>
                📅 Proposed Schedule ({result.scheduledEvents?.length} sessions)
              </h3>
            </div>
            <div className="space-y-3 mb-5">
              {result.scheduledEvents?.map((event: any, i: number) => {
                const color = CATEGORY_COLORS[event.category as keyof typeof CATEGORY_COLORS] || '#4f9cf9';
                const start = new Date(event.start_time);
                const end = new Date(event.end_time);
                const duration = Math.round((end.getTime() - start.getTime()) / (1000 * 60 * 60) * 10) / 10;
                return (
                  <div key={i} className="flex items-center gap-4 p-4 rounded-xl"
                    style={{ background: color + '10', border: `1px solid ${color}25` }}>
                    <div className="w-1 h-full min-h-[50px] rounded-full flex-shrink-0" style={{ background: color }} />
                    <div className="flex-1 min-w-0">
                      <div className="font-semibold text-sm" style={{ color: 'var(--text-primary)' }}>{event.title}</div>
                      <div className="text-xs mt-1" style={{ color: 'var(--text-muted)' }}>{event.description}</div>
                    </div>
                    <div className="text-right flex-shrink-0">
                      <div className="text-sm font-semibold" style={{ color: 'var(--text-primary)' }}>
                        {format(start, 'EEE, MMM d')}
                      </div>
                      <div className="text-xs" style={{ color: 'var(--text-secondary)' }}>
                        {format(start, 'h:mm a')} – {format(end, 'h:mm a')}
                      </div>
                      <div className="text-xs font-medium mt-0.5" style={{ color }}>
                        {duration}h
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Action buttons */}
            <div className="flex gap-3 pt-4" style={{ borderTop: '1px solid var(--border)' }}>
              <button onClick={() => setResult(null)} className="btn-secondary flex-1 py-3 rounded-xl text-sm">
                ← Regenerate
              </button>
              <button onClick={addToCalendar} disabled={adding}
                className="btn-primary flex-1 py-3 rounded-xl text-sm flex items-center justify-center gap-2">
                {adding ? (
                  <><div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> Adding...</>
                ) : '✅ Add All to Calendar'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Tips */}
      <div className="card">
        <h3 className="font-bold mb-4" style={{ color: 'var(--text-primary)' }}>💡 Tips for Better Scheduling</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {[
            { icon: '🌅', tip: 'Deep work is placed in 9–11am blocks when focus is highest' },
            { icon: '⚖️', tip: 'AI balances sessions to avoid back-to-back 3+ hour blocks' },
            { icon: '📅', tip: 'Existing events are analyzed to prevent all scheduling conflicts' },
            { icon: '🔄', tip: 'Re-generate to get different time slot variations' },
          ].map((item, i) => (
            <div key={i} className="flex items-start gap-3 p-3 rounded-xl" style={{ background: 'var(--bg-elevated)' }}>
              <span className="text-xl flex-shrink-0">{item.icon}</span>
              <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>{item.tip}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
