'use client';
import { useState, useEffect, useCallback } from 'react';
import { format, startOfMonth, endOfMonth, startOfWeek, endOfWeek, addDays, isSameDay, isSameMonth, addMonths, subMonths, addWeeks, subWeeks, startOfDay } from 'date-fns';
import toast from 'react-hot-toast';
import { CATEGORY_COLORS, CATEGORY_LABELS, EventCategory } from '@/types';

type CalendarView = 'month' | 'week' | 'day';

const categories = Object.entries(CATEGORY_LABELS) as [EventCategory, string][];

function EventModal({ event, onClose, onSave, onDelete }: {
  event: any;
  onClose: () => void;
  onSave: (data: any) => void;
  onDelete?: (id: string) => void;
}) {
  const isNew = !event?.id;
  const [form, setForm] = useState({
    title: event?.title || '',
    description: event?.description || '',
    startTime: event?.startTime ? format(new Date(event.startTime), "yyyy-MM-dd'T'HH:mm") : format(event?.date || new Date(), "yyyy-MM-dd'T'09:00"),
    endTime: event?.endTime ? format(new Date(event.endTime), "yyyy-MM-dd'T'HH:mm") : format(event?.date || new Date(), "yyyy-MM-dd'T'10:00"),
    category: (event?.category || 'personal') as EventCategory,
    priority: event?.priority || 'medium',
    location: event?.location || '',
  });

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold" style={{ color: 'var(--text-primary)' }}>
            {isNew ? '+ New Event' : 'Edit Event'}
          </h2>
          <button onClick={onClose} className="w-8 h-8 flex items-center justify-center rounded-lg transition-colors hover:bg-white/10" style={{ color: 'var(--text-secondary)' }}>✕</button>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text-secondary)' }}>Event Title *</label>
            <input className="input" placeholder="e.g., Team Standup, Gym Session..." value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text-secondary)' }}>Start Time *</label>
              <input type="datetime-local" className="input" value={form.startTime} onChange={e => setForm({ ...form, startTime: e.target.value })} />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text-secondary)' }}>End Time *</label>
              <input type="datetime-local" className="input" value={form.endTime} onChange={e => setForm({ ...form, endTime: e.target.value })} />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text-secondary)' }}>Category</label>
              <select className="input" value={form.category} onChange={e => setForm({ ...form, category: e.target.value as EventCategory })}>
                {categories.map(([value, label]) => (
                  <option key={value} value={value}>{label}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text-secondary)' }}>Priority</label>
              <select className="input" value={form.priority} onChange={e => setForm({ ...form, priority: e.target.value })}>
                <option value="low">Low</option>
                <option value="medium">Medium</option>
                <option value="high">High</option>
                <option value="urgent">Urgent</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text-secondary)' }}>Description</label>
            <textarea className="input" rows={3} placeholder="Optional notes..." value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} />
          </div>

          <div>
            <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text-secondary)' }}>Location</label>
            <input className="input" placeholder="Optional location..." value={form.location} onChange={e => setForm({ ...form, location: e.target.value })} />
          </div>

          {/* Color preview */}
          <div className="flex items-center gap-2 p-3 rounded-xl" style={{ background: CATEGORY_COLORS[form.category] + '15', border: `1px solid ${CATEGORY_COLORS[form.category]}30` }}>
            <div className="w-3 h-3 rounded-full flex-shrink-0" style={{ background: CATEGORY_COLORS[form.category] }} />
            <span className="text-sm" style={{ color: CATEGORY_COLORS[form.category] }}>{CATEGORY_LABELS[form.category]}</span>
          </div>
        </div>

        <div className="flex gap-3 mt-6">
          {!isNew && onDelete && (
            <button onClick={() => { onDelete(event.id); onClose(); }}
              className="btn-secondary text-sm py-2.5 px-4 rounded-xl flex-shrink-0"
              style={{ color: '#ef4444', borderColor: '#ef444430' }}>
              Delete
            </button>
          )}
          <button onClick={onClose} className="btn-secondary flex-1 text-sm py-2.5 rounded-xl">Cancel</button>
          <button onClick={() => { if (!form.title) return toast.error('Title is required'); onSave(form); onClose(); }}
            className="btn-primary flex-1 text-sm py-2.5 rounded-xl">
            {isNew ? 'Add Event' : 'Save Changes'}
          </button>
        </div>
      </div>
    </div>
  );
}

export default function CalendarPage() {
  const [view, setView] = useState<CalendarView>('month');
  const [currentDate, setCurrentDate] = useState(new Date());
  const [events, setEvents] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState<{ open: boolean; event?: any }>({ open: false });

  const authHeaders = () => ({
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${localStorage.getItem('auth_token')}`,
  });

  const loadEvents = useCallback(async () => {
    setLoading(true);
    try {
      const start = startOfMonth(currentDate);
      const end = endOfMonth(currentDate);
      const res = await fetch(`/api/events?start=${start.toISOString()}&end=${end.toISOString()}`, { headers: authHeaders() });
      const data = await res.json();
      setEvents(Array.isArray(data) ? data : []);
    } finally {
      setLoading(false);
    }
  }, [currentDate]);

  useEffect(() => { loadEvents(); }, [loadEvents]);

  const saveEvent = async (formData: any) => {
    const isEdit = !!modal.event?.id;
    const body = {
      title: formData.title,
      description: formData.description,
      startTime: new Date(formData.startTime).toISOString(),
      endTime: new Date(formData.endTime).toISOString(),
      category: formData.category,
      priority: formData.priority,
      location: formData.location,
    };

    try {
      const res = await fetch(isEdit ? `/api/events/${modal.event.id}` : '/api/events', {
        method: isEdit ? 'PUT' : 'POST',
        headers: authHeaders(),
        body: JSON.stringify(body),
      });

      if (!res.ok) throw new Error('Failed to save event');
      
      toast.success(isEdit ? 'Event updated! ✓' : 'Event added! 🎉');
      loadEvents();
    } catch (error: any) {
      toast.error(error.message);
    }
  };

  const deleteEvent = async (id: string) => {
    try {
      await fetch(`/api/events/${id}`, { method: 'DELETE', headers: authHeaders() });
      toast.success('Event deleted');
      loadEvents();
    } catch {
      toast.error('Failed to delete event');
    }
  };

  const getEventsForDay = (date: Date) => events.filter(e => isSameDay(new Date(e.startTime), date));

  // Month view
  const renderMonthView = () => {
    const monthStart = startOfMonth(currentDate);
    const monthEnd = endOfMonth(currentDate);
    const calStart = startOfWeek(monthStart, { weekStartsOn: 1 });
    const calEnd = endOfWeek(monthEnd, { weekStartsOn: 1 });
    const days: Date[] = [];
    let day = calStart;
    while (day <= calEnd) { days.push(day); day = addDays(day, 1); }

    return (
      <div className="rounded-2xl overflow-hidden" style={{ border: '1px solid var(--border)' }}>
        {/* Day headers */}
        <div className="grid grid-cols-7" style={{ background: 'var(--bg-secondary)' }}>
          {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map(d => (
            <div key={d} className="py-3 text-center text-xs font-semibold uppercase tracking-wider"
              style={{ color: 'var(--text-muted)', borderRight: '1px solid var(--border)' }}>{d}</div>
          ))}
        </div>
        {/* Days grid */}
        <div className="grid grid-cols-7">
          {days.map((day, i) => {
            const dayEvents = getEventsForDay(day);
            const isCurrentMonth = isSameMonth(day, currentDate);
            const isToday = isSameDay(day, new Date());
            return (
              <div key={i} className="calendar-day cursor-pointer"
                style={{ background: isToday ? 'rgba(79,156,249,0.05)' : '', opacity: isCurrentMonth ? 1 : 0.3 }}
                onClick={() => setModal({ open: true, event: { date: day } })}>
                <div className={`w-7 h-7 flex items-center justify-center text-sm font-medium rounded-full mb-1 ${isToday ? 'text-white' : ''}`}
                  style={isToday ? { background: '#4f9cf9' } : { color: 'var(--text-secondary)' }}>
                  {format(day, 'd')}
                </div>
                {dayEvents.slice(0, 3).map(event => (
                  <div key={event.id}
                    className="event-pill text-white mb-1"
                    style={{ background: event.color, fontSize: '11px' }}
                    onClick={e => { e.stopPropagation(); setModal({ open: true, event }); }}>
                    {event.title}
                  </div>
                ))}
                {dayEvents.length > 3 && (
                  <div className="text-xs" style={{ color: 'var(--text-muted)' }}>+{dayEvents.length - 3} more</div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  // Week view
  const renderWeekView = () => {
    const weekStart = startOfWeek(currentDate, { weekStartsOn: 1 });
    const days = Array.from({ length: 7 }, (_, i) => addDays(weekStart, i));
    const hours = Array.from({ length: 24 }, (_, i) => i);

    return (
      <div className="rounded-2xl overflow-hidden overflow-x-auto" style={{ border: '1px solid var(--border)' }}>
        {/* Header */}
        <div className="grid" style={{ gridTemplateColumns: '60px repeat(7, 1fr)', background: 'var(--bg-secondary)', borderBottom: '1px solid var(--border)' }}>
          <div />
          {days.map(day => (
            <div key={day.toISOString()} className="py-3 text-center" style={{ borderLeft: '1px solid var(--border)' }}>
              <div className="text-xs font-semibold uppercase" style={{ color: 'var(--text-muted)' }}>{format(day, 'EEE')}</div>
              <div className={`text-lg font-bold mx-auto mt-1 w-8 h-8 flex items-center justify-center rounded-full ${isSameDay(day, new Date()) ? 'text-white' : ''}`}
                style={isSameDay(day, new Date()) ? { background: '#4f9cf9', color: 'white' } : { color: 'var(--text-primary)' }}>
                {format(day, 'd')}
              </div>
            </div>
          ))}
        </div>
        {/* Time grid (show 8am-9pm) */}
        <div className="overflow-y-auto" style={{ maxHeight: '600px' }}>
          {hours.filter(h => h >= 7 && h <= 22).map(hour => (
            <div key={hour} className="grid" style={{ gridTemplateColumns: '60px repeat(7, 1fr)', minHeight: '60px' }}>
              <div className="text-xs text-right pr-3 pt-1 flex-shrink-0" style={{ color: 'var(--text-muted)' }}>
                {hour === 0 ? '12am' : hour < 12 ? `${hour}am` : hour === 12 ? '12pm' : `${hour - 12}pm`}
              </div>
              {days.map(day => {
                const hourEvents = events.filter(e => {
                  const start = new Date(e.startTime);
                  return isSameDay(start, day) && start.getHours() === hour;
                });
                return (
                  <div key={day.toISOString()}
                    className="p-1 cursor-pointer hover:bg-white/5 transition-colors"
                    style={{ borderLeft: '1px solid var(--border)', borderTop: '1px solid var(--border)' }}
                    onClick={() => {
                      const d = new Date(day);
                      d.setHours(hour, 0, 0, 0);
                      setModal({ open: true, event: { date: d } });
                    }}>
                    {hourEvents.map(event => (
                      <div key={event.id}
                        className="event-pill text-white text-xs p-1"
                        style={{ background: event.color }}
                        onClick={e => { e.stopPropagation(); setModal({ open: true, event }); }}>
                        {event.title}
                      </div>
                    ))}
                  </div>
                );
              })}
            </div>
          ))}
        </div>
      </div>
    );
  };

  // Day view
  const renderDayView = () => {
    const dayEvents = getEventsForDay(currentDate).sort((a, b) => new Date(a.startTime).getTime() - new Date(b.startTime).getTime());
    const hours = Array.from({ length: 24 }, (_, i) => i);
    
    return (
      <div className="rounded-2xl overflow-hidden" style={{ border: '1px solid var(--border)' }}>
        <div className="p-4 text-center" style={{ background: 'var(--bg-secondary)', borderBottom: '1px solid var(--border)' }}>
          <div className="text-2xl font-bold" style={{ color: 'var(--text-primary)' }}>
            {format(currentDate, 'EEEE, MMMM d')}
          </div>
          <div className="text-sm mt-1" style={{ color: 'var(--text-secondary)' }}>
            {dayEvents.length} events
          </div>
        </div>
        <div className="overflow-y-auto" style={{ maxHeight: '600px' }}>
          {hours.filter(h => h >= 6 && h <= 23).map(hour => {
            const hourEvents = dayEvents.filter(e => new Date(e.startTime).getHours() === hour);
            return (
              <div key={hour} className="flex gap-4 p-3 cursor-pointer hover:bg-white/5 transition-colors"
                style={{ borderBottom: '1px solid var(--border)' }}
                onClick={() => {
                  const d = new Date(currentDate);
                  d.setHours(hour, 0, 0, 0);
                  setModal({ open: true, event: { date: d } });
                }}>
                <div className="w-12 text-right text-xs flex-shrink-0 pt-1" style={{ color: 'var(--text-muted)' }}>
                  {hour === 0 ? '12am' : hour < 12 ? `${hour}am` : hour === 12 ? '12pm' : `${hour - 12}pm`}
                </div>
                <div className="flex-1 space-y-1 min-h-[40px]">
                  {hourEvents.map(event => (
                    <div key={event.id}
                      className="rounded-xl p-3 cursor-pointer transition-opacity hover:opacity-85"
                      style={{ background: event.color + '25', border: `1px solid ${event.color}50` }}
                      onClick={e => { e.stopPropagation(); setModal({ open: true, event }); }}>
                      <div className="font-semibold text-sm" style={{ color: event.color }}>{event.title}</div>
                      <div className="text-xs mt-0.5" style={{ color: 'var(--text-secondary)' }}>
                        {format(new Date(event.startTime), 'h:mm a')} – {format(new Date(event.endTime), 'h:mm a')}
                        {event.location && ` · ${event.location}`}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  const navigate = (dir: 1 | -1) => {
    if (view === 'month') setCurrentDate(dir === 1 ? addMonths(currentDate, 1) : subMonths(currentDate, 1));
    else if (view === 'week') setCurrentDate(dir === 1 ? addWeeks(currentDate, 1) : subWeeks(currentDate, 1));
    else setCurrentDate(addDays(currentDate, dir));
  };

  const title = view === 'month' ? format(currentDate, 'MMMM yyyy')
    : view === 'week' ? `${format(startOfWeek(currentDate, { weekStartsOn: 1 }), 'MMM d')} – ${format(endOfWeek(currentDate, { weekStartsOn: 1 }), 'MMM d, yyyy')}`
    : format(currentDate, 'EEEE, MMMM d, yyyy');

  return (
    <div className="max-w-7xl mx-auto animate-fade-in">
      {/* Calendar Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1">
            <button onClick={() => navigate(-1)} className="btn-secondary p-2 rounded-xl text-lg">←</button>
            <button onClick={() => setCurrentDate(new Date())} className="btn-secondary text-sm py-2 px-4 rounded-xl">Today</button>
            <button onClick={() => navigate(1)} className="btn-secondary p-2 rounded-xl text-lg">→</button>
          </div>
          <h2 className="text-xl font-bold" style={{ color: 'var(--text-primary)' }}>{title}</h2>
        </div>

        <div className="flex items-center gap-3">
          {/* View switcher */}
          <div className="flex rounded-xl overflow-hidden" style={{ border: '1px solid var(--border)' }}>
            {(['month', 'week', 'day'] as CalendarView[]).map(v => (
              <button key={v} onClick={() => setView(v)}
                className="text-sm font-medium py-2 px-4 transition-all capitalize"
                style={{
                  background: view === v ? '#4f9cf9' : 'var(--bg-elevated)',
                  color: view === v ? 'white' : 'var(--text-secondary)',
                }}>
                {v}
              </button>
            ))}
          </div>

          <button onClick={() => setModal({ open: true })} className="btn-primary text-sm py-2.5 px-5 rounded-xl">
            + Add Event
          </button>
        </div>
      </div>

      {/* Category legend */}
      <div className="flex flex-wrap gap-2 mb-5">
        {categories.map(([key, label]) => (
          <div key={key} className="flex items-center gap-1.5 text-xs py-1 px-3 rounded-full"
            style={{ background: CATEGORY_COLORS[key] + '15', color: CATEGORY_COLORS[key] }}>
            <div className="w-2 h-2 rounded-full" style={{ background: CATEGORY_COLORS[key] }} />
            {label}
          </div>
        ))}
      </div>

      {/* Calendar body */}
      {loading ? (
        <div className="h-96 rounded-2xl shimmer" />
      ) : (
        <>
          {view === 'month' && renderMonthView()}
          {view === 'week' && renderWeekView()}
          {view === 'day' && renderDayView()}
        </>
      )}

      {/* Event modal */}
      {modal.open && (
        <EventModal
          event={modal.event}
          onClose={() => setModal({ open: false })}
          onSave={saveEvent}
          onDelete={modal.event?.id ? deleteEvent : undefined}
        />
      )}
    </div>
  );
}
