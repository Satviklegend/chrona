'use client';
import { useState, useEffect } from 'react';
import Link from 'next/link';
import { format, startOfWeek, endOfWeek, isToday } from 'date-fns';

export default function DashboardPage() {
  const [user, setUser] = useState<any>(null);
  const [events, setEvents] = useState<any[]>([]);
  const [goals, setGoals] = useState<any[]>([]);
  const [habits, setHabits] = useState<any[]>([]);
  const [latestInsight, setLatestInsight] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  const authHeaders = () => ({
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${localStorage.getItem('auth_token')}`,
  });

  useEffect(() => {
    const userData = localStorage.getItem('user');
    if (userData) setUser(JSON.parse(userData));
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const now = new Date();
      const weekStart = startOfWeek(now, { weekStartsOn: 1 });
      const weekEnd = endOfWeek(now, { weekStartsOn: 1 });

      const [eventsRes, goalsRes, habitsRes, insightsRes] = await Promise.all([
        fetch(`/api/events?start=${weekStart.toISOString()}&end=${weekEnd.toISOString()}`, { headers: authHeaders() }),
        fetch('/api/goals', { headers: authHeaders() }),
        fetch('/api/habits', { headers: authHeaders() }),
        fetch('/api/ai/insights', { headers: authHeaders() }),
      ]);

      const [eventsData, goalsData, habitsData, insightsData] = await Promise.all([
        eventsRes.json(), goalsRes.json(), habitsRes.json(), insightsRes.json(),
      ]);

      setEvents(Array.isArray(eventsData) ? eventsData : []);
      setGoals(Array.isArray(goalsData) ? goalsData : []);
      setHabits(Array.isArray(habitsData) ? habitsData : []);
      setLatestInsight(Array.isArray(insightsData) && insightsData.length > 0 ? insightsData[0] : null);
    } catch (error) {
      console.error('Dashboard load error:', error);
    } finally {
      setLoading(false);
    }
  };

  const todayEvents = events.filter(e => isToday(new Date(e.startTime)));
  const activeGoals = goals.filter(g => g.status === 'active');
  const productivityScore = latestInsight?.productivityScore || null;

  const quickStats = [
    { label: "Today's Events", value: todayEvents.length, icon: '📅', color: '#4f9cf9' },
    { label: 'Active Goals', value: activeGoals.length, icon: '🎯', color: '#a78bfa' },
    { label: 'Active Habits', value: habits.length, icon: '⚡', color: '#34d399' },
    { label: 'Productivity Score', value: productivityScore ? `${productivityScore}` : '—', icon: '🧠', color: '#f59e0b' },
  ];

  if (loading) {
    return (
      <div className="space-y-6 animate-pulse">
        <div className="h-8 w-64 rounded-lg shimmer" />
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[...Array(4)].map((_, i) => <div key={i} className="h-28 rounded-2xl shimmer" />)}
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="h-64 rounded-2xl shimmer" />
          <div className="h-64 rounded-2xl shimmer" />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-7xl mx-auto animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold" style={{ color: 'var(--text-primary)' }}>
            Good {new Date().getHours() < 12 ? 'morning' : new Date().getHours() < 17 ? 'afternoon' : 'evening'},{' '}
            {user?.name?.split(' ')[0] || 'there'} 👋
          </h1>
          <p className="text-sm mt-1" style={{ color: 'var(--text-secondary)' }}>
            {format(new Date(), 'EEEE, MMMM d, yyyy')}
          </p>
        </div>
        <Link href="/dashboard/calendar" className="btn-primary text-sm py-2.5 px-5 rounded-xl">
          📅 Open Calendar
        </Link>
      </div>

      {/* Quick stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {quickStats.map((stat) => (
          <div key={stat.label} className="card card-hover">
            <div className="flex items-center justify-between mb-3">
              <span className="text-2xl">{stat.icon}</span>
              <div className="w-2 h-2 rounded-full" style={{ background: stat.color }} />
            </div>
            <div className="text-3xl font-extrabold mb-1" style={{ color: stat.color }}>{stat.value}</div>
            <div className="text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>{stat.label}</div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Today's Schedule */}
        <div className="lg:col-span-2 card">
          <div className="flex items-center justify-between mb-5">
            <h2 className="font-bold text-lg" style={{ color: 'var(--text-primary)' }}>Today's Schedule</h2>
            <Link href="/dashboard/calendar" className="text-sm font-medium" style={{ color: '#4f9cf9' }}>
              View all →
            </Link>
          </div>
          {todayEvents.length === 0 ? (
            <div className="text-center py-12">
              <div className="text-5xl mb-3">📭</div>
              <p className="font-medium mb-1" style={{ color: 'var(--text-secondary)' }}>No events today</p>
              <p className="text-sm mb-4" style={{ color: 'var(--text-muted)' }}>Add events to your calendar to get started</p>
              <Link href="/dashboard/calendar" className="btn-primary text-sm py-2 px-5 rounded-xl inline-block">
                Add Event
              </Link>
            </div>
          ) : (
            <div className="space-y-3">
              {todayEvents.map((event) => {
                const start = new Date(event.startTime);
                const end = new Date(event.endTime);
                const duration = Math.round((end.getTime() - start.getTime()) / (1000 * 60));
                return (
                  <div key={event.id} className="flex items-center gap-4 p-3 rounded-xl transition-colors hover:bg-white/5">
                    <div className="w-1 h-full min-h-[40px] rounded-full flex-shrink-0" style={{ background: event.color }} />
                    <div className="flex-shrink-0 w-16 text-center">
                      <div className="text-sm font-semibold" style={{ color: 'var(--text-primary)' }}>
                        {format(start, 'h:mm')}
                      </div>
                      <div className="text-xs" style={{ color: 'var(--text-muted)' }}>
                        {format(start, 'a')}
                      </div>
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="font-medium text-sm truncate" style={{ color: 'var(--text-primary)' }}>{event.title}</div>
                      <div className="text-xs" style={{ color: 'var(--text-muted)' }}>
                        {duration} min · {event.category}
                      </div>
                    </div>
                    <div className="badge text-xs flex-shrink-0" style={{ background: event.color + '20', color: event.color }}>
                      {event.priority}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Right column */}
        <div className="space-y-6">
          {/* AI Insight */}
          {latestInsight ? (
            <div className="card" style={{ borderColor: 'rgba(167,139,250,0.2)', background: 'rgba(167,139,250,0.05)' }}>
              <div className="flex items-center gap-2 mb-3">
                <span className="text-lg">🧠</span>
                <span className="text-sm font-bold" style={{ color: '#a78bfa' }}>AI Insight</span>
              </div>
              <div className="text-3xl font-extrabold mb-1" style={{ color: '#a78bfa' }}>
                {latestInsight.productivityScore || '—'}
                {latestInsight.productivityScore && <span className="text-lg">/100</span>}
              </div>
              <p className="text-xs leading-relaxed" style={{ color: 'var(--text-secondary)' }}>
                {latestInsight.content?.substring(0, 120)}...
              </p>
              <Link href="/dashboard/insights" className="mt-3 text-xs font-medium block" style={{ color: '#a78bfa' }}>
                View full report →
              </Link>
            </div>
          ) : (
            <div className="card" style={{ borderColor: 'rgba(167,139,250,0.2)' }}>
              <div className="text-center py-4">
                <div className="text-3xl mb-2">🧠</div>
                <p className="text-sm font-medium mb-1" style={{ color: 'var(--text-primary)' }}>No AI analysis yet</p>
                <p className="text-xs mb-3" style={{ color: 'var(--text-muted)' }}>Run your first analysis to get insights</p>
                <Link href="/dashboard/insights" className="btn-primary text-xs py-2 px-4 rounded-lg inline-block">
                  Analyze Now
                </Link>
              </div>
            </div>
          )}

          {/* Active Goals */}
          <div className="card">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold text-sm" style={{ color: 'var(--text-primary)' }}>Active Goals</h3>
              <Link href="/dashboard/goals" className="text-xs" style={{ color: '#4f9cf9' }}>Manage →</Link>
            </div>
            {activeGoals.length === 0 ? (
              <div className="text-center py-4">
                <p className="text-xs" style={{ color: 'var(--text-muted)' }}>No goals yet</p>
                <Link href="/dashboard/goals" className="text-xs font-medium mt-1 block" style={{ color: '#4f9cf9' }}>Add a goal</Link>
              </div>
            ) : (
              <div className="space-y-3">
                {activeGoals.slice(0, 4).map((goal) => (
                  <div key={goal.id}>
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="text-xs font-medium truncate" style={{ color: 'var(--text-primary)' }}>{goal.title}</span>
                      <span className="text-xs flex-shrink-0 ml-2" style={{ color: 'var(--text-muted)' }}>{goal.progress}%</span>
                    </div>
                    <div className="progress-bar">
                      <div className="progress-fill" style={{ width: `${goal.progress}%` }} />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Habits */}
          <div className="card">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold text-sm" style={{ color: 'var(--text-primary)' }}>Today's Habits</h3>
              <Link href="/dashboard/habits" className="text-xs" style={{ color: '#4f9cf9' }}>Manage →</Link>
            </div>
            {habits.length === 0 ? (
              <p className="text-xs text-center" style={{ color: 'var(--text-muted)' }}>No habits tracked yet</p>
            ) : (
              <div className="space-y-2">
                {habits.slice(0, 5).map((habit) => (
                  <div key={habit.id} className="flex items-center gap-2">
                    <div className="w-4 h-4 rounded border flex-shrink-0" style={{ borderColor: 'var(--border-hover)' }} />
                    <span className="text-xs truncate" style={{ color: 'var(--text-secondary)' }}>{habit.title}</span>
                    <span className="text-xs ml-auto flex-shrink-0" style={{ color: 'var(--text-muted)' }}>{habit.durationMinutes}m</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
