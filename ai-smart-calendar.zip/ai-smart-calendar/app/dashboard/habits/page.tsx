'use client';
import { useState, useEffect } from 'react';
import toast from 'react-hot-toast';

function HabitModal({ onClose, onSave }: { onClose: () => void; onSave: (data: any) => void }) {
  const [form, setForm] = useState({
    title: '', description: '', frequency: 'daily', targetTime: '', durationMinutes: 30, category: 'personal',
  });
  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold" style={{ color: 'var(--text-primary)' }}>+ New Habit</h2>
          <button onClick={onClose} className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-white/10" style={{ color: 'var(--text-secondary)' }}>✕</button>
        </div>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text-secondary)' }}>Habit Name *</label>
            <input className="input" placeholder="e.g., Morning meditation, Read 20 pages..." value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text-secondary)' }}>Frequency</label>
              <select className="input" value={form.frequency} onChange={e => setForm({ ...form, frequency: e.target.value })}>
                <option value="daily">Daily</option>
                <option value="weekdays">Weekdays</option>
                <option value="weekends">Weekends</option>
                <option value="weekly">Weekly</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text-secondary)' }}>Duration (min)</label>
              <input type="number" className="input" min="5" max="480" value={form.durationMinutes} onChange={e => setForm({ ...form, durationMinutes: parseInt(e.target.value) })} />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text-secondary)' }}>Target Time</label>
              <input type="time" className="input" value={form.targetTime} onChange={e => setForm({ ...form, targetTime: e.target.value })} />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text-secondary)' }}>Category</label>
              <select className="input" value={form.category} onChange={e => setForm({ ...form, category: e.target.value })}>
                {['health', 'fitness', 'learning', 'personal', 'work', 'mindfulness', 'social'].map(c => (
                  <option key={c} value={c}>{c.charAt(0).toUpperCase() + c.slice(1)}</option>
                ))}
              </select>
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text-secondary)' }}>Notes</label>
            <textarea className="input" rows={2} placeholder="Why is this habit important to you?" value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} />
          </div>
        </div>
        <div className="flex gap-3 mt-6">
          <button onClick={onClose} className="btn-secondary flex-1 text-sm py-2.5 rounded-xl">Cancel</button>
          <button onClick={() => { if (!form.title) return toast.error('Title required'); onSave(form); onClose(); }}
            className="btn-primary flex-1 text-sm py-2.5 rounded-xl">Add Habit ⚡</button>
        </div>
      </div>
    </div>
  );
}

const frequencyColors: Record<string, string> = {
  daily: '#34d399', weekdays: '#4f9cf9', weekends: '#a78bfa', weekly: '#f59e0b'
};

const categoryIcons: Record<string, string> = {
  health: '❤️', fitness: '🏃', learning: '📚', personal: '⭐', work: '💼', mindfulness: '🧘', social: '👥'
};

export default function HabitsPage() {
  const [habits, setHabits] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [checked, setChecked] = useState<Set<string>>(new Set());

  const authHeaders = () => ({ 'Content-Type': 'application/json', 'Authorization': `Bearer ${localStorage.getItem('auth_token')}` });

  const loadHabits = async () => {
    try {
      const res = await fetch('/api/habits', { headers: authHeaders() });
      const data = await res.json();
      setHabits(Array.isArray(data) ? data : []);
    } finally { setLoading(false); }
  };

  useEffect(() => { loadHabits(); }, []);

  const saveHabit = async (formData: any) => {
    try {
      const res = await fetch('/api/habits', { method: 'POST', headers: authHeaders(), body: JSON.stringify(formData) });
      if (!res.ok) throw new Error();
      toast.success('Habit added! ⚡');
      loadHabits();
    } catch { toast.error('Failed to add habit'); }
  };

  const deleteHabit = async (id: string) => {
    if (!confirm('Remove this habit?')) return;
    await fetch(`/api/habits/${id}`, { method: 'DELETE', headers: authHeaders() });
    toast.success('Habit removed');
    loadHabits();
  };

  const toggleCheck = (id: string) => {
    const newChecked = new Set(checked);
    if (newChecked.has(id)) { newChecked.delete(id); toast('Habit unchecked'); }
    else { newChecked.add(id); toast.success('Habit completed! 🎉'); }
    setChecked(newChecked);
  };

  const completionRate = habits.length > 0 ? Math.round((checked.size / habits.length) * 100) : 0;

  const dailyHabits = habits.filter(h => h.frequency === 'daily');
  const otherHabits = habits.filter(h => h.frequency !== 'daily');

  return (
    <div className="max-w-4xl mx-auto space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold" style={{ color: 'var(--text-primary)' }}>Habits</h1>
          <p className="text-sm mt-1" style={{ color: 'var(--text-secondary)' }}>Build consistency, one day at a time</p>
        </div>
        <button onClick={() => setShowModal(true)} className="btn-primary py-2.5 px-5 rounded-xl text-sm">
          + Add Habit
        </button>
      </div>

      {/* Today's progress */}
      <div className="card" style={{ borderColor: 'rgba(79,156,249,0.2)', background: 'linear-gradient(135deg, rgba(79,156,249,0.05), rgba(167,139,250,0.05))' }}>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="font-bold" style={{ color: 'var(--text-primary)' }}>Today's Progress</h2>
            <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>{checked.size} of {habits.length} habits completed</p>
          </div>
          <div className="text-4xl font-extrabold gradient-text">{completionRate}%</div>
        </div>
        <div className="progress-bar" style={{ height: '10px' }}>
          <div className="progress-fill" style={{ width: `${completionRate}%`, height: '100%' }} />
        </div>
        {completionRate === 100 && habits.length > 0 && (
          <div className="mt-3 text-center text-sm font-medium" style={{ color: '#34d399' }}>
            🎉 All habits completed today! Amazing work!
          </div>
        )}
      </div>

      {loading ? (
        <div className="space-y-3">{[...Array(4)].map((_, i) => <div key={i} className="h-24 rounded-2xl shimmer" />)}</div>
      ) : habits.length === 0 ? (
        <div className="card text-center py-16">
          <div className="text-5xl mb-3">⚡</div>
          <h3 className="font-bold text-lg mb-2" style={{ color: 'var(--text-primary)' }}>No habits yet</h3>
          <p className="text-sm mb-4" style={{ color: 'var(--text-secondary)' }}>Build daily habits to boost your productivity and wellbeing</p>
          <button onClick={() => setShowModal(true)} className="btn-primary py-2.5 px-6 rounded-xl text-sm inline-block">
            Add Your First Habit
          </button>
        </div>
      ) : (
        <>
          {/* Habit list */}
          {dailyHabits.length > 0 && (
            <div>
              <h3 className="text-sm font-semibold mb-3 uppercase tracking-wider" style={{ color: 'var(--text-muted)' }}>Daily Habits</h3>
              <div className="space-y-3">
                {dailyHabits.map(habit => (
                  <HabitCard key={habit.id} habit={habit} isChecked={checked.has(habit.id)}
                    onToggle={() => toggleCheck(habit.id)} onDelete={() => deleteHabit(habit.id)} />
                ))}
              </div>
            </div>
          )}
          {otherHabits.length > 0 && (
            <div>
              <h3 className="text-sm font-semibold mb-3 uppercase tracking-wider" style={{ color: 'var(--text-muted)' }}>Other Habits</h3>
              <div className="space-y-3">
                {otherHabits.map(habit => (
                  <HabitCard key={habit.id} habit={habit} isChecked={checked.has(habit.id)}
                    onToggle={() => toggleCheck(habit.id)} onDelete={() => deleteHabit(habit.id)} />
                ))}
              </div>
            </div>
          )}
        </>
      )}

      {showModal && <HabitModal onClose={() => setShowModal(false)} onSave={saveHabit} />}
    </div>
  );
}

function HabitCard({ habit, isChecked, onToggle, onDelete }: {
  habit: any; isChecked: boolean; onToggle: () => void; onDelete: () => void;
}) {
  const freqColor = frequencyColors[habit.frequency] || '#4f9cf9';
  const icon = categoryIcons[habit.category] || '⭐';

  return (
    <div className={`card card-hover flex items-center gap-4 py-4 transition-opacity ${isChecked ? 'opacity-60' : ''}`}>
      <button onClick={onToggle}
        className="w-7 h-7 rounded-full border-2 flex items-center justify-center flex-shrink-0 transition-all"
        style={{
          borderColor: isChecked ? '#34d399' : 'var(--border-hover)',
          background: isChecked ? '#34d399' : 'transparent',
          color: 'white', fontSize: '14px',
        }}>
        {isChecked && '✓'}
      </button>
      <div className="text-2xl flex-shrink-0">{icon}</div>
      <div className="flex-1 min-w-0">
        <div className={`font-semibold text-sm ${isChecked ? 'line-through' : ''}`} style={{ color: 'var(--text-primary)' }}>
          {habit.title}
        </div>
        <div className="flex items-center gap-3 mt-1">
          <span className="text-xs" style={{ color: 'var(--text-muted)' }}>⏱ {habit.durationMinutes}min</span>
          {habit.targetTime && <span className="text-xs" style={{ color: 'var(--text-muted)' }}>🕐 {habit.targetTime}</span>}
          <span className="badge text-xs" style={{ background: freqColor + '20', color: freqColor }}>
            {habit.frequency}
          </span>
        </div>
      </div>
      {habit.streak > 0 && (
        <div className="flex-shrink-0 text-center">
          <div className="text-lg font-bold" style={{ color: '#f59e0b' }}>🔥{habit.streak}</div>
          <div className="text-xs" style={{ color: 'var(--text-muted)' }}>streak</div>
        </div>
      )}
      <button onClick={onDelete} className="flex-shrink-0 text-xs py-1.5 px-3 rounded-lg transition-colors"
        style={{ background: 'rgba(239,68,68,0.1)', color: '#f87171' }}>
        ✕
      </button>
    </div>
  );
}

// Need to re-define these since they're used in HabitCard which is outside component scope
const frequencyColors: Record<string, string> = { daily: '#34d399', weekdays: '#4f9cf9', weekends: '#a78bfa', weekly: '#f59e0b' };
const categoryIcons: Record<string, string> = { health: '❤️', fitness: '🏃', learning: '📚', personal: '⭐', work: '💼', mindfulness: '🧘', social: '👥' };
