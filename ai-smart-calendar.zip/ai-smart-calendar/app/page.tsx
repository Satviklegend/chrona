'use client';
import { useState, useEffect } from 'react';
import Link from 'next/link';

const features = [
  {
    icon: '🧠',
    title: 'AI Schedule Analysis',
    desc: 'Gemini AI analyzes your entire week, detects overload, wasted time, and provides a personalized productivity score.',
    gradient: 'from-blue-500/20 to-cyan-500/20',
    border: 'border-blue-500/20',
  },
  {
    icon: '⚡',
    title: 'Auto-Scheduling',
    desc: 'Tell the AI your goal — "Study 10 hours this week" — and it instantly distributes optimized time blocks across your calendar.',
    gradient: 'from-purple-500/20 to-pink-500/20',
    border: 'border-purple-500/20',
  },
  {
    icon: '📊',
    title: 'Insights Dashboard',
    desc: 'Visual productivity scores, time breakdowns by category, weekly summaries, and actionable improvement suggestions.',
    gradient: 'from-emerald-500/20 to-cyan-500/20',
    border: 'border-emerald-500/20',
  },
  {
    icon: '🎯',
    title: 'Goals & Habits Tracking',
    desc: 'Set short and long-term goals with weekly hour targets. Track habits and streaks tied directly to your calendar.',
    gradient: 'from-amber-500/20 to-orange-500/20',
    border: 'border-amber-500/20',
  },
  {
    icon: '🎨',
    title: 'Smart Event System',
    desc: 'Color-coded categories, priority levels, drag-and-drop rescheduling, and day/week/month calendar views.',
    gradient: 'from-pink-500/20 to-rose-500/20',
    border: 'border-pink-500/20',
  },
  {
    icon: '🔔',
    title: 'Smart Notifications',
    desc: 'Get alerts when your schedule is overloaded, reminders for upcoming events, and AI-generated tips for each session.',
    gradient: 'from-cyan-500/20 to-blue-500/20',
    border: 'border-cyan-500/20',
  },
];

const stats = [
  { value: '94%', label: 'Users report better productivity' },
  { value: '3.2x', label: 'More goals completed' },
  { value: '40%', label: 'Less scheduling conflicts' },
  { value: '∞', label: 'AI-powered insights' },
];

const calendarPreview = [
  { time: '9:00', title: 'Deep Work: Project Alpha', color: '#4f9cf9', category: 'Work', width: 'w-full' },
  { time: '11:00', title: 'Team Standup', color: '#a78bfa', category: 'Work', width: 'w-1/2' },
  { time: '12:30', title: 'Lunch Break', color: '#34d399', category: 'Personal', width: 'w-full' },
  { time: '14:00', title: 'Study: Machine Learning', color: '#22d3ee', category: 'Learning', width: 'w-full' },
  { time: '16:00', title: 'Gym Session', color: '#f472b6', category: 'Fitness', width: 'w-1/2' },
];

export default function LandingPage() {
  const [mounted, setMounted] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    setMounted(true);
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="min-h-screen" style={{ background: 'var(--bg-primary)' }}>
      {/* Nav */}
      <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${scrolled ? 'glass' : ''}`}>
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl flex items-center justify-center text-lg"
              style={{ background: 'linear-gradient(135deg, #4f9cf9, #a78bfa)' }}>
              📅
            </div>
            <span className="font-bold text-lg" style={{ color: 'var(--text-primary)' }}>
              AI Smart Calendar
            </span>
          </div>
          <div className="hidden md:flex items-center gap-8">
            {['Features', 'How it Works', 'Pricing'].map(item => (
              <a key={item} href={`#${item.toLowerCase().replace(/\s/g,'-')}`}
                className="text-sm font-medium transition-colors hover:text-white"
                style={{ color: 'var(--text-secondary)' }}>
                {item}
              </a>
            ))}
          </div>
          <div className="flex items-center gap-3">
            <Link href="/auth" className="btn-secondary text-sm py-2 px-4">
              Sign In
            </Link>
            <Link href="/auth?mode=signup" className="btn-primary text-sm py-2 px-4">
              Get Started Free
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="hero-gradient grid-pattern min-h-screen flex items-center pt-20">
        <div className="max-w-7xl mx-auto px-6 py-24 text-center">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium mb-8"
            style={{ background: 'rgba(79, 156, 249, 0.1)', border: '1px solid rgba(79, 156, 249, 0.2)', color: '#4f9cf9' }}>
            <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse"></span>
            Powered by Google Gemini AI
          </div>

          <h1 className="text-6xl md:text-8xl font-extrabold mb-6 leading-tight tracking-tight">
            <span style={{ color: 'var(--text-primary)' }}>Your calendar,</span>
            <br />
            <span className="gradient-text">supercharged by AI</span>
          </h1>

          <p className="text-xl md:text-2xl max-w-3xl mx-auto mb-12 leading-relaxed"
            style={{ color: 'var(--text-secondary)' }}>
            Schedule smarter. Work less. Achieve more. AI analyzes your time, detects patterns,
            and automatically builds the optimal week for your goals.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-20">
            <Link href="/auth?mode=signup"
              className="btn-primary text-base py-4 px-8 flex items-center gap-2 rounded-xl">
              <span>Start for Free</span>
              <span>→</span>
            </Link>
            <Link href="/auth"
              className="btn-secondary text-base py-4 px-8 flex items-center gap-2 rounded-xl">
              <span>Sign In</span>
            </Link>
          </div>

          {/* Stats row */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-24">
            {stats.map((stat) => (
              <div key={stat.label} className="card text-center py-6">
                <div className="text-3xl font-extrabold gradient-text mb-1">{stat.value}</div>
                <div className="text-sm" style={{ color: 'var(--text-secondary)' }}>{stat.label}</div>
              </div>
            ))}
          </div>

          {/* Calendar preview mockup */}
          <div className="relative max-w-4xl mx-auto">
            <div className="absolute inset-0 rounded-3xl blur-2xl opacity-30"
              style={{ background: 'linear-gradient(135deg, rgba(79,156,249,0.3), rgba(167,139,250,0.3))' }} />
            <div className="relative card rounded-3xl overflow-hidden" style={{ padding: '0' }}>
              {/* Top bar */}
              <div className="flex items-center gap-2 px-6 py-4" style={{ borderBottom: '1px solid var(--border)' }}>
                <div className="w-3 h-3 rounded-full bg-red-500/70" />
                <div className="w-3 h-3 rounded-full bg-yellow-500/70" />
                <div className="w-3 h-3 rounded-full bg-green-500/70" />
                <div className="flex-1 mx-4">
                  <div className="mx-auto w-64 h-6 rounded-md text-xs flex items-center justify-center"
                    style={{ background: 'var(--bg-elevated)', color: 'var(--text-muted)' }}>
                    ai-smart-calendar.app/dashboard
                  </div>
                </div>
              </div>
              {/* Mock dashboard */}
              <div className="flex" style={{ minHeight: '400px' }}>
                {/* Sidebar */}
                <div className="w-56 flex-shrink-0 p-4" style={{ borderRight: '1px solid var(--border)', background: 'var(--bg-secondary)' }}>
                  <div className="text-xs font-semibold mb-4 uppercase tracking-wider" style={{ color: 'var(--text-muted)' }}>Menu</div>
                  {['📅 Calendar', '🧠 AI Insights', '🎯 Goals', '⚡ Habits', '📊 Analytics'].map((item, i) => (
                    <div key={item} className={`nav-item mb-1 text-sm ${i === 0 ? 'active' : ''}`}>{item}</div>
                  ))}
                  {/* AI Score preview */}
                  <div className="mt-6 p-3 rounded-xl" style={{ background: 'rgba(79,156,249,0.1)', border: '1px solid rgba(79,156,249,0.2)' }}>
                    <div className="text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>Productivity Score</div>
                    <div className="text-2xl font-bold" style={{ color: '#4f9cf9' }}>87</div>
                    <div className="text-xs" style={{ color: 'var(--text-muted)' }}>↑ +12 from last week</div>
                  </div>
                </div>
                {/* Calendar area */}
                <div className="flex-1 p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="text-lg font-bold">Monday, April 28</div>
                    <div className="flex gap-2">
                      {['Day', 'Week', 'Month'].map((v, i) => (
                        <span key={v} className={`text-xs px-3 py-1 rounded-lg font-medium ${i === 0 ? 'text-white' : ''}`}
                          style={{ background: i === 0 ? 'var(--accent-blue)' : 'var(--bg-elevated)', color: i === 0 ? 'white' : 'var(--text-secondary)' }}>
                          {v}
                        </span>
                      ))}
                    </div>
                  </div>
                  <div className="space-y-2">
                    {calendarPreview.map((event) => (
                      <div key={event.title} className="flex items-center gap-3">
                        <span className="text-xs w-12 text-right flex-shrink-0" style={{ color: 'var(--text-muted)' }}>{event.time}</span>
                        <div className="event-pill flex-1 py-2 px-3 text-xs font-medium text-white"
                          style={{ background: event.color + '30', border: `1px solid ${event.color}50`, color: event.color }}>
                          {event.title}
                        </div>
                      </div>
                    ))}
                  </div>
                  {/* AI tip */}
                  <div className="mt-4 p-3 rounded-xl text-left text-xs"
                    style={{ background: 'rgba(167,139,250,0.1)', border: '1px solid rgba(167,139,250,0.2)' }}>
                    <span style={{ color: '#a78bfa' }}>🧠 AI Insight: </span>
                    <span style={{ color: 'var(--text-secondary)' }}>You're most productive 9–11am. Consider moving your "Machine Learning" study to mornings.</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section id="features" className="py-32">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-20">
            <h2 className="text-4xl md:text-5xl font-extrabold mb-4">
              <span className="gradient-text">Everything you need</span>
              <br />
              <span style={{ color: 'var(--text-primary)' }}>to own your time</span>
            </h2>
            <p className="text-lg max-w-2xl mx-auto" style={{ color: 'var(--text-secondary)' }}>
              A complete productivity system powered by AI, built for people who take their time seriously.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature) => (
              <div key={feature.title}
                className={`card card-hover bg-gradient-to-br ${feature.gradient} border ${feature.border}`}>
                <div className="text-4xl mb-4">{feature.icon}</div>
                <h3 className="text-lg font-bold mb-2" style={{ color: 'var(--text-primary)' }}>{feature.title}</h3>
                <p className="text-sm leading-relaxed" style={{ color: 'var(--text-secondary)' }}>{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How it works */}
      <section id="how-it-works" className="py-32" style={{ background: 'var(--bg-secondary)' }}>
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-20">
            <h2 className="text-4xl md:text-5xl font-extrabold mb-4" style={{ color: 'var(--text-primary)' }}>
              How it <span className="gradient-text">works</span>
            </h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { step: '01', title: 'Set your goals & habits', desc: 'Tell the app what you want to achieve — study hours, fitness targets, work milestones. Set your daily habits.', icon: '🎯' },
              { step: '02', title: 'Add your events', desc: 'Build your calendar with drag-and-drop ease. Color-coded categories keep everything organized at a glance.', icon: '📅' },
              { step: '03', title: 'AI optimizes your week', desc: 'Gemini AI analyzes everything, gives you a productivity score, detects issues, and auto-schedules your goals.', icon: '🚀' },
            ].map((step) => (
              <div key={step.step} className="card text-center">
                <div className="text-5xl mb-4">{step.icon}</div>
                <div className="text-xs font-bold mb-2 tracking-widest" style={{ color: '#4f9cf9' }}>STEP {step.step}</div>
                <h3 className="text-xl font-bold mb-3" style={{ color: 'var(--text-primary)' }}>{step.title}</h3>
                <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>{step.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section id="pricing" className="py-32">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-20">
            <h2 className="text-4xl md:text-5xl font-extrabold mb-4">
              <span style={{ color: 'var(--text-primary)' }}>Simple, </span>
              <span className="gradient-text">honest pricing</span>
            </h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {[
              {
                name: 'Free',
                price: '$0',
                desc: 'Perfect for getting started',
                features: ['Unlimited events', 'Day/Week/Month views', 'Goals & habit tracking', '5 AI analyses per month', 'Basic productivity score'],
                cta: 'Start Free',
                highlight: false,
              },
              {
                name: 'Pro',
                price: '$12',
                period: '/month',
                desc: 'For serious productivity',
                features: ['Everything in Free', 'Unlimited AI analyses', 'Auto-scheduling AI', 'Advanced insights dashboard', 'Priority support', 'Weekly AI reports'],
                cta: 'Start Pro Trial',
                highlight: true,
              },
            ].map((plan) => (
              <div key={plan.name}
                className={`card ${plan.highlight ? 'glow-blue border-blue-500/30' : ''}`}
                style={plan.highlight ? { borderColor: 'rgba(79,156,249,0.3)' } : {}}>
                {plan.highlight && (
                  <div className="badge mb-4 inline-block text-white"
                    style={{ background: 'linear-gradient(135deg, #4f9cf9, #a78bfa)' }}>
                    Most Popular
                  </div>
                )}
                <div className="text-2xl font-bold mb-1" style={{ color: 'var(--text-primary)' }}>{plan.name}</div>
                <div className="flex items-baseline gap-1 mb-2">
                  <span className="text-5xl font-extrabold gradient-text">{plan.price}</span>
                  {plan.period && <span style={{ color: 'var(--text-secondary)' }}>{plan.period}</span>}
                </div>
                <p className="text-sm mb-6" style={{ color: 'var(--text-secondary)' }}>{plan.desc}</p>
                <ul className="space-y-3 mb-8">
                  {plan.features.map((f) => (
                    <li key={f} className="flex items-center gap-2 text-sm" style={{ color: 'var(--text-secondary)' }}>
                      <span style={{ color: '#34d399' }}>✓</span> {f}
                    </li>
                  ))}
                </ul>
                <Link href="/auth?mode=signup"
                  className={`block text-center py-3 rounded-xl font-semibold transition-all ${plan.highlight ? 'btn-primary' : 'btn-secondary'}`}>
                  {plan.cta}
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-32" style={{ background: 'var(--bg-secondary)' }}>
        <div className="max-w-3xl mx-auto px-6 text-center">
          <div className="card glow-blue" style={{ borderColor: 'rgba(79,156,249,0.2)' }}>
            <div className="text-6xl mb-6">🚀</div>
            <h2 className="text-4xl font-extrabold mb-4">
              <span className="gradient-text">Start building your</span>
              <br />
              <span style={{ color: 'var(--text-primary)' }}>perfect week today</span>
            </h2>
            <p className="text-lg mb-8" style={{ color: 'var(--text-secondary)' }}>
              Join thousands of people who've taken control of their time with AI-powered scheduling.
            </p>
            <Link href="/auth?mode=signup"
              className="btn-primary text-base py-4 px-10 inline-flex items-center gap-2 rounded-xl">
              Get Started — It's Free →
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12" style={{ borderTop: '1px solid var(--border)' }}>
        <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg flex items-center justify-center text-base"
              style={{ background: 'linear-gradient(135deg, #4f9cf9, #a78bfa)' }}>📅</div>
            <span className="font-semibold" style={{ color: 'var(--text-primary)' }}>AI Smart Calendar</span>
          </div>
          <p className="text-sm" style={{ color: 'var(--text-muted)' }}>
            © 2025 AI Smart Calendar. Built with Gemini AI & Next.js.
          </p>
          <div className="flex gap-6">
            {['Privacy', 'Terms', 'Contact'].map(link => (
              <a key={link} href="#" className="text-sm transition-colors hover:text-white" style={{ color: 'var(--text-muted)' }}>{link}</a>
            ))}
          </div>
        </div>
      </footer>
    </div>
  );
}
