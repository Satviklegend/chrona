export interface User {
  id: string;
  email: string;
  name: string;
  avatarColor: string;
  timezone: string;
  createdAt: string;
}

export interface Event {
  id: string;
  userId: string;
  title: string;
  description?: string;
  startTime: string;
  endTime: string;
  category: EventCategory;
  color: string;
  priority: Priority;
  isRecurring?: boolean;
  location?: string;
  createdAt: string;
}

export type EventCategory = 
  | 'work' 
  | 'school' 
  | 'fitness' 
  | 'personal' 
  | 'health'
  | 'social'
  | 'learning'
  | 'finance'
  | 'creative'
  | 'other';

export type Priority = 'low' | 'medium' | 'high' | 'urgent';

export interface Goal {
  id: string;
  userId: string;
  title: string;
  description?: string;
  type: 'short_term' | 'long_term';
  targetDate?: string;
  progress: number;
  status: 'active' | 'completed' | 'paused';
  weeklyHours?: number;
  category?: string;
  createdAt: string;
}

export interface Habit {
  id: string;
  userId: string;
  title: string;
  description?: string;
  frequency: 'daily' | 'weekly' | 'weekdays' | 'weekends';
  targetTime?: string;
  durationMinutes: number;
  category?: string;
  streak: number;
  isActive: boolean;
  createdAt: string;
}

export interface AIInsight {
  id: string;
  userId: string;
  type: 'weekly_analysis' | 'suggestion' | 'event_tip';
  title?: string;
  content: string;
  data?: any;
  productivityScore?: number;
  weekStart?: string;
  createdAt: string;
}

export interface AuthState {
  user: User | null;
  token: string | null;
  loading: boolean;
}

export const CATEGORY_COLORS: Record<EventCategory, string> = {
  work: '#0ea5e9',
  school: '#8b5cf6',
  fitness: '#10b981',
  personal: '#f59e0b',
  health: '#ef4444',
  social: '#ec4899',
  learning: '#06b6d4',
  finance: '#84cc16',
  creative: '#f97316',
  other: '#94a3b8',
};

export const CATEGORY_LABELS: Record<EventCategory, string> = {
  work: 'Work',
  school: 'School',
  fitness: 'Fitness',
  personal: 'Personal',
  health: 'Health',
  social: 'Social',
  learning: 'Learning',
  finance: 'Finance',
  creative: 'Creative',
  other: 'Other',
};

export const PRIORITY_COLORS: Record<Priority, string> = {
  low: '#94a3b8',
  medium: '#0ea5e9',
  high: '#f59e0b',
  urgent: '#ef4444',
};
