'use client';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import toast from 'react-hot-toast';

const navItems = [
  { href: '/dashboard', icon: '🏠', label: 'Overview' },
  { href: '/dashboard/calendar', icon: '📅', label: 'Calendar' },
  { href: '/dashboard/insights', icon: '🧠', label: 'AI Insights' },
  { href: '/dashboard/goals', icon: '🎯', label: 'Goals' },
  { href: '/dashboard/habits', icon: '⚡', label: 'Habits' },
  { href: '/dashboard/autoschedule', icon: '🚀', label: 'Auto-Schedule' },
];

interface SidebarProps {
  open: boolean;
  user: any;
}

export default function Sidebar({ open, user }: SidebarProps) {
  const pathname = usePathname();
  const router = useRouter();

  const handleLogout = async () => {
    await fetch('/api/auth/logout', { method: 'POST' });
    localStorage.removeItem('auth_token');
    localStorage.removeItem('user');
    toast.success('Logged out successfully');
    router.push('/');
  };

  if (!open) return null;

  return (
    <aside className="w-60 flex-shrink-0 flex flex-col h-full"
      style={{ background: 'var(--bg-secondary)', borderRight: '1px solid var(--border)' }}>
      {/* Logo */}
      <div className="p-5" style={{ borderBottom: '1px solid var(--border)' }}>
        <Link href="/" className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl flex items-center justify-center text-lg"
            style={{ background: 'linear-gradient(135deg, #4f9cf9, #a78bfa)' }}>
            📅
          </div>
          <div>
            <div className="font-bold text-sm leading-tight" style={{ color: 'var(--text-primary)' }}>AI Smart</div>
            <div className="font-bold text-sm leading-tight gradient-text">Calendar</div>
          </div>
        </Link>
      </div>

      {/* Nav */}
      <nav className="flex-1 p-3 overflow-y-auto">
        <div className="space-y-1">
          {navItems.map((item) => {
            const isActive = pathname === item.href || (item.href !== '/dashboard' && pathname.startsWith(item.href));
            return (
              <Link key={item.href} href={item.href}>
                <div className={`nav-item ${isActive ? 'active' : ''}`}>
                  <span className="text-lg">{item.icon}</span>
                  <span>{item.label}</span>
                </div>
              </Link>
            );
          })}
        </div>

        {/* Quick stats */}
        <div className="mt-6 p-3 rounded-xl" style={{ background: 'rgba(79,156,249,0.08)', border: '1px solid rgba(79,156,249,0.15)' }}>
          <div className="text-xs font-semibold mb-2" style={{ color: '#4f9cf9' }}>Quick Tip</div>
          <p className="text-xs leading-relaxed" style={{ color: 'var(--text-secondary)' }}>
            Run AI analysis weekly to get personalized productivity insights and schedule optimizations.
          </p>
        </div>
      </nav>

      {/* User */}
      <div className="p-3" style={{ borderTop: '1px solid var(--border)' }}>
        <div className="flex items-center gap-3 p-3 rounded-xl"
          style={{ background: 'var(--bg-elevated)' }}>
          <div className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold text-white flex-shrink-0"
            style={{ background: user?.avatarColor || '#4f9cf9' }}>
            {user?.name?.[0]?.toUpperCase() || '?'}
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-xs font-semibold truncate" style={{ color: 'var(--text-primary)' }}>{user?.name}</div>
            <div className="text-xs truncate" style={{ color: 'var(--text-muted)' }}>{user?.email}</div>
          </div>
          <button onClick={handleLogout} title="Logout"
            className="text-sm flex-shrink-0 transition-colors hover:opacity-70"
            style={{ color: 'var(--text-muted)' }}>
            ⏻
          </button>
        </div>
      </div>
    </aside>
  );
}
