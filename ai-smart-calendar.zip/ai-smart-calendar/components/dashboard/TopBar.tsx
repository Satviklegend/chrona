'use client';
import { usePathname } from 'next/navigation';
import { format } from 'date-fns';

const pageTitles: Record<string, string> = {
  '/dashboard': 'Overview',
  '/dashboard/calendar': 'Calendar',
  '/dashboard/insights': 'AI Insights',
  '/dashboard/goals': 'Goals',
  '/dashboard/habits': 'Habits',
  '/dashboard/autoschedule': 'Auto-Schedule',
};

interface TopBarProps {
  onToggleSidebar: () => void;
  user: any;
}

export default function TopBar({ onToggleSidebar, user }: TopBarProps) {
  const pathname = usePathname();
  const title = pageTitles[pathname] || 'Dashboard';

  return (
    <header className="flex items-center justify-between px-6 py-4 flex-shrink-0"
      style={{ borderBottom: '1px solid var(--border)', background: 'var(--bg-secondary)' }}>
      <div className="flex items-center gap-4">
        <button onClick={onToggleSidebar}
          className="p-2 rounded-lg transition-colors hover:bg-white/5"
          style={{ color: 'var(--text-secondary)' }}>
          ☰
        </button>
        <h1 className="font-bold text-lg" style={{ color: 'var(--text-primary)' }}>{title}</h1>
      </div>
      <div className="flex items-center gap-4">
        <span className="text-sm hidden md:block" style={{ color: 'var(--text-secondary)' }}>
          {format(new Date(), 'EEE, MMM d')}
        </span>
        <div className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold text-white"
          style={{ background: user?.avatarColor || '#4f9cf9' }}>
          {user?.name?.[0]?.toUpperCase() || '?'}
        </div>
      </div>
    </header>
  );
}
